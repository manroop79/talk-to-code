Copyright � 2009-2015 EMC Corporation 
All Rights Reserved

This software contains the intellectual property of EMC Corporation or is licensed to 
EMC Corporation from third parties. Use of this software and the intellectual property 
contained therein is expressly limited to the terms and conditions of the License
Agreement under which it is provided by or on behalf of EMC.



This ZIP file consists of the following directories:

    doc - Includes HTML documentation on the Extended STAPI (i.e. stauto32ext API).
    
    include - Includes stauto32ext.h header file needed for development.


Brief header file descriptions:

    stauto32ext.h - Contains all Extended STAPI C-style functions.
                    They cover functionality not supported in the standard STAPI
                    such as the ability to import and delete tokens.


Additional files neccessary for development:

    stauto32.dll - This DLL, along with its dependencies, is installed into
                   "C:\Program Files\RSA SecurID Token Common" by the RSA SecurID Software Token installer
                   and contains the implementations of the functions found in stauto32ext.h. The
                   corresponding stauto32.lib can be found in the RSASecurIDSDK500.zip package.

