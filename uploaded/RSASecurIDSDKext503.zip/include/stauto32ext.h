#ifndef RSA_STAUTO32_EXT_INCLUDE
#define RSA_STAUTO32_EXT_INCLUDE

/*! \mainpage

<p>This header includes functions that are for use by RSA provided programs only. They allow access to
extended functionality not available through the standard stauto32 API.</p>

<p>This header is included by stauto32.h by setting #defining _RSA_INTERNAL</p>

<HR>

    COPYRIGHT (C) 2009-2015 EMC Corporation
ALL RIGHTS RESERVED

   This software contains the intellectual property of EMC Corporation or is licensed to 
EMC Corporation from third parties. Use of this software and the intellectual property 
contained therein is expressly limited to the terms and conditions of the License
Agreement under which it is provided by or on behalf of EMC.

*/

#define	TOKENDLL_OBKEY	{0x84,0xA5,0xB8,0xF1,0xDA,0x11,0x9C,0x12}
#define ST_AUTO32_JUNK_KEY {0x82,0x98,0x97,0x01,0x41,0x15,0x4e,0x14}
#define	DLLKEYLEN		8

#define STAUTO_DEFAULT_STRING_LENGTH 256
#define STAUTO_GUID_STRING_LENGTH 39       // Used for GUID strings in the form {67C8770B-44F1-410A-AB9A-F9B5446F13EE} with 38 chars plus null terminator
#define STAUTO_MAX_URL_LENGTH 1024
#define STAUTO_MAX_SERIAL_NUMBER_LENGTH 33
#define STAUTO_MAX_EXTENDED_ATTRIBUTES_LENGTH 2048

#if	defined(__APPLE__)	||	defined(applec)
	#define	FAR
#endif

#if defined(__APPLE__) || defined(applec)
typedef	void (*REFRESHCALLBACK)	(LPVOID);
#else
typedef VOID (*REFRESHCALLBACK) (VOID *);
#endif

/*! Defines which OTP algorithm is used */
typedef struct tagALGORITHMINFO
{
    bool rsa_time_128bit;   /*!< 128 bit time-based */
    bool rsa_time_64bit;    /*!< 64 bit time-based */
    bool rsa_event;         /*!< Event-based */
	bool reserved;          /*!< Reserved for the future */
} ALGORITHMINFO, FAR* LPALGORITHMINFO;

/*! Used to present information on the stauto32 library DLL and plugin DLLs */
typedef struct tagDLLEXTENDEDINFO
{
    CK_UTF8CHAR dll_version[STAUTO_DEFAULT_STRING_LENGTH];  /*!< Version string */
    CK_UTF8CHAR dll_vendor[STAUTO_DEFAULT_STRING_LENGTH];   /*!< Vendor string */
    unsigned int version_major;                             /*!< Major version number */
    unsigned int version_minor;                             /*!< Minor version number */
    char    guid[STAUTO_GUID_STRING_LENGTH];    /*!< GUID identifier for plugin DLLs */
} DLLEXTENDEDINFO, FAR* LPDLLEXTENDEDINFO;

/*! Information on token storage devices */
typedef struct tagDEVICEINFO
{
    CK_UTF8CHAR device_version[STAUTO_DEFAULT_STRING_LENGTH];   /*!< Version string */
    CK_UTF8CHAR device_vendor[STAUTO_DEFAULT_STRING_LENGTH];    /*!< Vendor string */
    unsigned int version_major;             /*!< Major version number */
    unsigned int version_minor;             /*!< Minor version number */
    ALGORITHMINFO algorithm_type;           /*!< OTP algorithms supported by device */
    int mode;                               /*!< 0 if device is read-only, 1 if read-write */
    bool can_get_next_code;                 /*!< Boolean value indicating if next tokencode can be retrieved immediatly */
    unsigned int max_tokens;                /*!< Maximum number of tokens supported on device */
    const char* icon_data;                  /*!< Pointer to raw icon data */
    unsigned int icon_length;               /*!< Length of buffer pointed to by icon_data */
    unsigned int icon_type;                 /*!< Icon format (0 for PNG is the only value currently supported) */
    char guid[STAUTO_GUID_STRING_LENGTH];   /*!< Device GUID identifier */
    bool is_device_activated;               /*!< Boolean value indicating whether device is activated */
    char class_guid[STAUTO_GUID_STRING_LENGTH];     /*!< Device class GUID identifier */
    CK_UTF8CHAR device_vendor_serial[STAUTO_MAX_SERIAL_NUMBER_LENGTH];      /*!< Device serial number */
} DEVICEINFO, FAR* LPDEVICEINFO;

/*! Token storage device extended information */
typedef struct tagDEVICEEXTENDEDINFO
{
    DEVICEINFO device_info;     /*!< Standard device information */

    bool time_available;        /*!< Boolean value indicating whether secure time is available onboard device */
    bool can_set_password;      /*!< Boolean value indicating whether a password can be set on the device */
    bool seed_storage_available;                    /*!< Boolean value indicating whether seed storage is available onboard device */
    bool code_generation_available;                 /*!< Boolean value indicating whether code generation happens on device */
    unsigned int supported_token_types;             /*!< Supported token types (see rsatokenprovider.h for more information) */
    unsigned int supported_direct_inputs;           /*!< Supported direct inputs (see rsatokenprovider.h for more information) */
    unsigned int supported_provisioning_methods;    /*!< Supported provisioning methods (see rsatokenprovider.h for more information) */
} DEVICEEXTENDEDINFO, FAR* LPDEVICEEXTENDEDINFO;

/*! Token metadata extended information */
typedef struct tagTOKENEXTENDEDINFO
{
    char serial_number[STAUTO_MAX_SERIAL_NUMBER_LENGTH];    /*!< Token serial number */
    const char* icon_data;                  /*!< Pointer to raw icon data */
    unsigned int icon_length;               /*!< Length of buffer pointed to by icon_data */
    unsigned int icon_type;                 /*!< Icon format (0 for PNG is the only value currently supported) */
    CK_DATE birth_date;                     /*!< Token birth date */
    CK_DATE death_date;                     /*!< Token expiration date */
    unsigned int otp_interval;              /*!< Token interval (in seconds) */
    unsigned int otp_digits;                /*!< Number of digits in tokencode */
    bool pin_required;                      /*!< Boolean value indicating whether a PIN is required */
    CK_UTF8CHAR url[STAUTO_MAX_URL_LENGTH];             /*!< Token URL */
    CK_UTF8CHAR user_id[STAUTO_DEFAULT_STRING_LENGTH];  /*!< Username of user token is assigned to */
    CK_UTF8CHAR user_first_name[STAUTO_DEFAULT_STRING_LENGTH];      /*!< First name of user */
    CK_UTF8CHAR user_last_name[STAUTO_DEFAULT_STRING_LENGTH];       /*!< Last name of user */
    CK_UTF8CHAR token_label[STAUTO_DEFAULT_STRING_LENGTH];          /*!< Token label/nickname */
    CK_UTF8CHAR extended_attributes[STAUTO_MAX_EXTENDED_ATTRIBUTES_LENGTH];     /*!< Extended attribute data in XML form */
    char device_binding[STAUTO_GUID_STRING_LENGTH];         /*!< Device binding (device class GUID or device serial number) */
    int algorithm_type;                     /*!< Algorithm identifier (0 for 64-bit algorithm, 1 for 128-bit algorithm, and 3 for event algorithm) */
    int max_event_count;                    /*!< Maximum number of codes that can be generated (applies only to event tokens) */
    bool prepend_pin;                       /*!< Boolean value indicating whether PIN should be pre-pended to tokencode (alternatly it should be "rolled in") */
} TOKENEXTENDEDINFO, FAR* LPTOKENEXTENDEDINFO;



///////////////////////////////////////////////////////////////////////////////
// RSA SecurID Software Token Extended API Functions


/*!
*   This function acts as a simple access control to the extended stauto32 API. See code below for how to use:
*
*  \code
*       unsigned char StautoKey[8] = TOKENDLL_OBKEY;
*       unsigned char StautoJunkKey[8] = ST_AUTO32_JUNK_KEY;
*       bO((LPVOID)StautoKey);
*       // Here you would call these extended private functions
*       bO((LPVOID)StautoJunkKey);
*  \endcode
*
*  \param[in] pBuffer Key buffer
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT bO (LPVOID pBuffer);

/*!
*   This function is called to import token(s) into a token storage device.
*   The last token imported will be selected as the current/default token if the import is successful.
*
*   When importing from a password-protected token file, if an invalid, NULL, or empty password is passed in 
*   as the pAuthCode parameter, an error will be returned.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] pImportFilePath Path to SDTID token file or a CT-KIP URL.
*
*  \param[in] pAuthCode CT-KIP activation code or SDTID token file password (can be NULL or empty string if there is no password).
*
*  \param[in] pDeviceInfo Device to import to (only pDeviceInfo->guid is required to be correct).
*
*  \param[in] pTokenSerial Serial number of the token to import (can pass NULL when importing via CT-KIP or
*   to specify that all tokens in the SDTID file should be imported). See EnumDistributionTokens() for 
*   information about the tokens in a token file.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT ImportTokensToDevice (LONG ServiceHandle,
                                       CK_UTF8CHAR* pImportFilePath,
                                       CK_UTF8CHAR* pAuthCode,
                                       LPDEVICEINFO pDeviceInfo,
                                       LPCSTR pTokenSerial);

/*!
*   This function is called to obtain information about tokens stored in an SDTID token file.
*
*   When using a password-protected token file, if an invalid, NULL, or empty password is passed in 
*   as the pPassword parameter, an error will be returned.
*
*   When pBuffer is NULL, pBufferSize is set to the number of bytes needed to allocate
*   and the value FALSE is returned.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] pImportFile Path to an SDTID token distribution file.
*
*  \param[in] pPassword Token file password (can be NULL or empty string if there is no password).
*
*  \param[out] pNumberOfTokens Number of tokens stored in the distribution file.
*
*  \param[out] pBuffer Array of LPTOKENEXTENDEDINFO structures of token information.
*
*  \param[in,out] pBufferSize Size in bytes of pBuffer. If pBuffer is NULL, pBufferSize is set to space required.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT EnumDistributionTokens (LONG ServiceHandle,
                                         CK_UTF8CHAR* pImportFile,
                                         CK_UTF8CHAR* pPassword,
                                         LPLONG pNumberOfTokens,
                                         LPVOID  pBuffer,
                                         LPDWORD pBufferSize);

/*!
*   This function will cause the token service to refresh its internal state if required.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] bForce Force a refresh by passing in a value of true.
*
*  \param[out] pbCurrentTokenDeleted Set to true if current token was deleted, false otherwise.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT RefreshTokens (LONG ServiceHandle,
                                bool bForce,
                                bool* pbCurrentTokenDeleted);

/*!
*   Determines if a certain token storage device is present.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] pDeviceInfo Device to determine the presence of (only pDeviceInfo->guid is used).
*
*  \param[out] bResult Set to true if device is present, false otherwise.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT IsDevicePresent (LONG ServiceHandle,
                                  LPDEVICEINFO pDeviceInfo,
                                  bool *bResult);

/*!
*   Used to retrieve information on token storage device where certain token is stored.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] pSerialNumber Serial number of token.
*
*  \param[out] pDeviceInfo Information on device where token is stored.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT GetTokenDeviceInfo (LONG ServiceHandle,
                                     LPCSTR pSerialNumber,
                                     LPDEVICEINFO pDeviceInfo);

/*!
*   Provides a list of all installed token storage devices in all plugins.
*
*   When pBuffer is NULL, pBufferSize is filled in with the number of bytes needed to allocate
*   and the value FALSE is returned.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[out] pNumberOfDevices Total number of token storage devices.
*
*  \param[out] pBuffer Array of LPDEVICEINFO structures of device information.
*
*  \param[in,out] pBufferSize Size in bytes of pBuffer. If pBuffer is NULL, pBufferSize is set to space required.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT EnumTokenDevices (LONG ServiceHandle,
                                   LPLONG pNumberOfDevices,
                                   LPVOID pBuffer,
                                   LPDWORD pBufferSize);

/*!
*   Used to delete a token.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] pSerialNumber Serial number of token to be deleted.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT DeleteToken (LONG ServiceHandle,
                              LPCSTR pSerialNumber);

/*!
*   Obtains extended information about one token.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] pSerialNumber Serial number of token to retrieve information on.
*
*  \param[out] pTokenInfo Information on chosen token.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT GetTokenExtendedInfo (LONG ServiceHandle,
                                       LPCSTR pSerialNumber,
                                       LPTOKENEXTENDEDINFO pTokenInfo);

/*!
*   Obtains extended information about all tokens.
*
*   When pBuffer is NULL, pBufferSize is filled in with the number of bytes needed to allocate
*   and the value FALSE is returned.
*
*   If any of the tokens have an empty string set for their token_label field, the serial_number
*   field should be displayed in any UI presented to the user as the token name.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[out] pNumberOfTokens Total number of active tokens.
*
*  \param[out] pBuffer Array of LPTOKENEXTENDEDINFO structures of token information.
*
*  \param[in,out] pBufferSize Size in bytes of pBuffer. If pBuffer is NULL, pBufferSize is set to space required.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT EnumTokenExtendedInfo (LONG ServiceHandle,
                                        LPLONG pNumberOfTokens,
                                        LPVOID pBuffer,
                                        LPDWORD pBufferSize);

/*!
*   Sets the label/nickname for a token intended for use in the UI.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] pSerialNumber Serial number of token to set the label for.
*
*  \param[in] pLabel Token label/nickname to set.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT SetTokenLabel (LONG ServiceHandle,
                                LPCSTR pSerialNumber,
                                CK_UTF8CHAR* pLabel);

/*!
*   Obtains information about the plugin DLLs currently loaded.
*
*   When pBuffer is NULL, pBufferSize is filled in with the number of bytes needed to allocate
*   and the value FALSE is returned.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[out] pNumberOfPlugins Number of plugins installed.
*
*  \param[out] pBuffer Array of LPDLLEXTENDEDINFO structures of plugin information.
*
*  \param[in,out] pBufferSize Size in bytes of pBuffer. If pBuffer is NULL, pBufferSize is set to space required.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT EnumPlugins (LONG ServiceHandle,
                              LPLONG pNumberOfPlugins,
                              LPVOID  pBuffer,
                              LPDWORD pBufferSize);

/*!
*   Optional function to call if you need to get notification when a refresh event happens, such as when
*   a device is inserted or a change involving tokens occurs. When importing, deleting, or setting a token 
*   label from an open service handle, the pCallback function for that service handle will not be executed,
*   but the callback functions for all other open service handles will be.
*
*   Do not make any calls to the stauto32 API in the pCallback function, as they may cause deadlock.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] pCallback Function pointer to callback function.
*
*  \param[in] pCallbackArgument Function argument, pass NULL if none exists.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT SetRefreshCallback (LONG ServiceHandle,
                                     REFRESHCALLBACK pCallback,
                                     LPVOID pCallbackArgument);

/*!
*   Function used to activate a token storage device. It would only be neccessary to call
*   this function if the is_device_activated variable in the device's DEVICEINFO structure
*   is set to false.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] pDeviceInfo Device to activate (only pDeviceInfo->guid is required to be correct).
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT ActivateDevice (LONG ServiceHandle,
                                 LPDEVICEINFO pDeviceInfo);

/*!
*   Function used to change a token storage device's protection. The protection offered
*   will vary from device to device. For example, if the device supports passwords,
*   this function would be used to change the password.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] pDeviceInfo Device to set protection on (only pDeviceInfo->guid is required to be correct).
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT ChangeDeviceProtection (LONG ServiceHandle,
                                         LPDEVICEINFO pDeviceInfo);

/*!
*   NOT YET IMPLEMENTED - ALWAYS RETURNS FALSE
*
*   Function used to deactivate a token storage device. It is uneccessary and optional to use this function.
*   This function should only be used when the is_device_activated variable in the device's DEVICEINFO structure
*   is set to true.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] pDeviceInfo Device to deactivate (only pDeviceInfo->guid is required to be correct).
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT DeactivateDevice (LONG ServiceHandle,
                                   LPDEVICEINFO pDeviceInfo);

/*!
*   This function returns extended information about the stauto32 library.
*
*  \param[out] pDllInfo Pointer to a DLLEXTENDEDINFO structure that will receive information about the stauto32 DLL.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT GetDLLExtendedInfo (LPDLLEXTENDEDINFO pDllInfo);

/*!
*   Provides extended information on all active token storage devices in all active plugins.
*
*   When pBuffer is NULL, pBufferSize is filled in with the number of bytes needed to allocate
*   and the value FALSE is returned.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[out] pNumberOfDevices Total number of token storage devices.
*
*  \param[out] pBuffer Array of LPDEVICEEXTENDEDINFO structures of token storage device information.
*
*  \param[in,out] pBufferSize Size in bytes of pBuffer. If pBuffer is NULL, pBufferSize is set to space required.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT EnumDeviceExtendedInfo (LONG ServiceHandle,
                                         LPLONG pNumberOfDevices,
                                         LPVOID pBuffer,
                                         LPDWORD pBufferSize);

/*!
*   Extended information on the token storage device where a particular token is stored.
*
*  \param[in] ServiceHandle Handle that identifies the instance of the token service.
*
*  \param[in] pSerialNumber Serial number of token.
*
*  \param[out] pDeviceInfo Extended information on device where token is stored.
*
*  \return If the function succeeds, the return value is greater than zero.
*   If the function fails, the return value is zero.
*/
STAUTO32_API_INT GetTokenExtendedDeviceInfo (LONG ServiceHandle,
                                             LPCSTR pSerialNumber,
                                             LPDEVICEEXTENDEDINFO pDeviceInfo);



/*! \cond */
//////////////////////////////////////////////////////////////////////////////
// CONVENIENCE TYPEDEFS (for use when casting values from GetProcAddress() or dlsym())

typedef int  (CDECL_SPEC *BO)                        (LPVOID);
typedef int  (CDECL_SPEC *IMPORTTOKENSTODEVICE)      (LONG, CK_UTF8CHAR*, CK_UTF8CHAR*, LPDEVICEINFO, LPCSTR);
typedef int  (CDECL_SPEC *ENUMDISTRIBUTIONTOKENS)    (LONG, CK_UTF8CHAR*, CK_UTF8CHAR*, LPLONG, LPVOID, LPDWORD);
typedef int  (CDECL_SPEC *REFRESHTOKENS)             (LONG, bool, bool*);
typedef int  (CDECL_SPEC *ISDEVICEPRESENT)           (LONG, LPDEVICEINFO, bool*);
typedef int  (CDECL_SPEC *GETTOKENDEVICEINFO)        (LONG, LPCSTR, LPDEVICEINFO);
typedef int  (CDECL_SPEC *ENUMTOKENDEVICES)          (LONG, LPLONG, LPVOID, LPDWORD);
typedef int  (CDECL_SPEC *DELETETOKEN)               (LONG, LPCSTR);
typedef int  (CDECL_SPEC *GETTOKENEXTENDEDINFO)      (LONG, LPCSTR, LPTOKENEXTENDEDINFO);
typedef int  (CDECL_SPEC *ENUMTOKENEXTENDEDINFO)     (LONG, LPLONG, LPVOID, LPDWORD);
typedef int  (CDECL_SPEC *SETTOKENLABEL)             (LONG, LPCSTR, CK_UTF8CHAR*);
typedef int  (CDECL_SPEC *ENUMPLUGINS)               (LONG, LPLONG, LPVOID, LPDWORD);
typedef int  (CDECL_SPEC *SETREFRESHCALLBACK)        (LONG, REFRESHCALLBACK, LPVOID);
typedef int  (CDECL_SPEC *ACTIVATEDEVICE)            (LONG, LPDEVICEINFO);
typedef int  (CDECL_SPEC *CHANGEDEVICEPROTECTION)    (LONG, LPDEVICEINFO);
typedef int  (CDECL_SPEC *DEACTIVATEDEVICE)          (LONG, LPDEVICEINFO);
typedef int  (CDECL_SPEC *GETDLLEXTENDEDINFO)        (LPDLLEXTENDEDINFO);
typedef int  (CDECL_SPEC *ENUMDEVICEEXTENDEDINFO)    (LONG, LPLONG, LPVOID, LPDWORD);
typedef int  (CDECL_SPEC *GETTOKENEXTENDEDDEVICEINFO) (LONG, LPCSTR, LPDEVICEEXTENDEDINFO);

/*! \endcond */

#endif

