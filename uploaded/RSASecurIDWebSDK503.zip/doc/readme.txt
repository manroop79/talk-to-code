Copyright � 2009-2015 EMC Corporation 
All Rights Reserved

This software contains the intellectual property of EMC Corporation or is licensed to 
EMC Corporation from third parties. Use of this software and the intellectual property 
contained therein is expressly limited to the terms and conditions of the License
Agreement under which it is provided by or on behalf of EMC.



This ZIP file consists of the following directories:

    doc         - Includes the document describing the Javascript interface for the RSA SecurID WebID
                  Browser Plugin.
    
    sample      - Sample web pages that demonstrate using the WebID Browser Plugin in Javascript.

