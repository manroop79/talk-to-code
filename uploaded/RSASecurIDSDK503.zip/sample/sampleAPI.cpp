// TokenAPISample.cpp : Defines the entry point for the console application.

#include <stdio.h>
#include <windows.h>
#include "stauto32.h"


// In order for this sample program to run correctly, at least
// one PINPad-style token should be imported first through the
// Desktop application

int main(int argc, char* argv[])
{
    printf("TokenAPI Sample Program...\n");

    // Define local vars
    LONG lTokenServiceHandle;
    LONG lTokens;
    LONG lDefaultToken;
    LONG lTimeLeft;
    DWORD dwBufferSize = 0;
    char chPIN[9];
    char chPRN[12];
    char chPASSCODE[12];

    // Open the Token Service and get a handle to it
    if(OpenTokenService(&lTokenServiceHandle) > 0)
    {
        printf("Token Service started, Handle=%ld\n", lTokenServiceHandle);
        
        // Get buffer size
        EnumToken(lTokenServiceHandle, &lTokens, &lDefaultToken, 0, &dwBufferSize);

        // Allocate memory
        LPTOKENBASICINFO lpTokens = new TOKENBASICINFO[lTokens];

        // List tokens
        if(EnumToken(lTokenServiceHandle, &lTokens, &lDefaultToken, lpTokens, &dwBufferSize) > 0)
        {
            printf("%ld Software tokens found...\n", lTokens);

            LPTOKENBASICINFO lpToken = lpTokens;
            for(int i = 0; i < lTokens; i++)
            {
                printf("%d: Serial Number=%s\t User Name=%s\n",
                i, lpToken->serialnumber, lpToken->username);
                lpToken++;
            }

            // Select the first token, if there is one
            if(lTokens > 0)
            {
                // Get current codes with a PIN of "12345678"
                strcpy(chPIN, "12345678");
                GetCurrentCode(lTokenServiceHandle, lpTokens[0].serialnumber, chPIN, &lTimeLeft, chPASSCODE, chPRN);
                printf("Time Left:\t%d\n", lTimeLeft);
                printf("PRN:\t\t%s\n", chPRN);
                printf("PASSCODE:\t%s\n", chPASSCODE);
            }

            // Cleanup
            delete lpTokens;
        }

    // Close the Token Service
    CloseTokenService(lTokenServiceHandle);
    printf("Token Service stopped");

    }

    return 0;
}

