Copyright � 2009-2015 EMC Corporation 
All Rights Reserved

This software contains the intellectual property of EMC Corporation or is licensed to 
EMC Corporation from third parties. Use of this software and the intellectual property 
contained therein is expressly limited to the terms and conditions of the License
Agreement under which it is provided by or on behalf of EMC.



This zip file consists of the following components:

     doc  - includes stauto32.chm which contains the RSA
            SecurID Token Software Token 5.0 Developer's Guide.
			
     include - includes the stauto32 header file needed for development

     lib - includes the stauto32 link library, stauto32.lib for 64bit Platforms.
	 
	 lib_x86 - includes the stauto32 link library, stauto32.lib for 32Bit Platforms.

     sample - includes sampleAPI.cpp.  The sample API file 
              demonstrates how to effectively use the STAPI.  
	
	 RSASecurIDSDK.sln - Solution file for Visual Studio 2010.
	 
	 RSASecurIDSDK.vcxproj - Project file for Visual Studio 2010.


Brief header file descriptions:

     stauto32.h - RSA SecurID Software Token 5.0 Application Programming Interface (base).
                  This includes general use functions. Most VPN vendors will need only this header.


The DLLs needed for development can be located in "Program Files/RSA/RSA SecurID Token Common" 
after RSASecurIDSetup.exe has completed installation.  

Note that RegisterRtpDll has the following entry points:

	bool Import(const char* path, bool systemScope);    // Imports a token plug-in into the registry
	bool Remove(const char* path, bool systemScope);    // Removes a token plug-in from the registry
	
	The 'Import' and 'Remove' functions take two parameters, the first being a path to a token plug-in and 
	second being the registry scope.  The second parameter must be set to true as registering a token-plugin 
	in the user-scope is no longer supported.
	
	bool RegisterTimePlugin(const char* const path);    // Imports a time plug-in into the registry
	bool UnregisterTimePlugin(const char* const path);  // Removes a time plug-in from the registry