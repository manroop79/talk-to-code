Copyright � 2009-2015 EMC Corporation 
All Rights Reserved

This software contains the intellectual property of EMC Corporation or is licensed to 
EMC Corporation from third parties. Use of this software and the intellectual property 
contained therein is expressly limited to the terms and conditions of the License
Agreement under which it is provided by or on behalf of EMC.



This ZIP file consists of the following directories:

    doc         - Includes this readme.
    
    templates   - Includes the updated RSA Authentication Agent for Web template web pages.
                  See below for additional details and how to install them.




Purpose of the new template web pages:

    The templates can be used to gain compatibility with the RSA SecurID Software Token
    WebID components. Those components integrate the Software Token application with
    Internet Explorer on Windows. Using the new templates, when a user navigates to a site 
    that is protected by the RSA Authentication Agent for Web, they will be presented
    with a display allowing them to select their software token, enter their user name
    and PIN, and proceed (instead of having to enter their user name and passcode in the
    manual authentication page).


How to install the template web pages:

    On the server where the RSA Authentication Agent for Web is installed, navigate to the
    templates directory (located at "C:\Program Files\RSA Security\RSAWebAgent\templates" by
    default) and copy the files in the templates directory of this package into that folder.
    Since several files will be replaced, it is recommended that a backup copy be made of the
    original directory beforehand. The folder "en-securid" within that directory should be left
    as it is since it is required for compatibility with previous versions of the RSA SecurID
    Software Token WebID component for Internet Explorer. Check to make sure that the permissions
    of the copied template files are set correctly so that the RSA Authentication Agent for Web can
    have read-access to them.



