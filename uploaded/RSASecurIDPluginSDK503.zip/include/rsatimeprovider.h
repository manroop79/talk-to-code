/*! \mainpage RSA Time Provider Interface 1.0

<p>The RSA Time Provider Interface specifies the interface (RSA::SecurID::ITimeProvider) that
must be implemented in order to provide a custom time source for use within token provider
plug-ins when they are generating tokencodes. This interface is intended for customers who have users
whose system times may be out of sync with the RSA Authentication Manager server, which would result
in authentication failures.</p>
<p>Each time provider plug-in must be assigned a unique identifier referred to as a GUID (a DCE variant UUID) and must be registered with stauto32. The GUID can be generated
by many different methods. One method is to use the RegisterRtpUtil utility available from RSA Partner
Engineering).</p>

<h2>Using a Time Provider</h2>
<p>By default, the stauto32 library provides token provider plug-ins with a time provider
that returns the user's system time. To use a registered time provider plug-in you 
must call into the STAPI (stauto32 API) and invoke the SetTimeProvider()
function, passing in the GUID of the time provider as a parameter. This option is available
for customers who are writing an application that uses software tokens, such as a VPN
application. After completing this function call, all tokens will use this time provider 
for the duration of the token service as long as the plug-in is properly registered and loaded by the stauto32 library.  
If the time provider plug-in cannot be loaded or is not registered, tokencodes will be generated using
the default time provider, which uses the client's system time.
</p>

<h2>Plug-in Signing and Registration</h2>
<p>Each time provider plug-in must be digitally signed and registered.</p>
<h3>Plug-in Signature Process</h3>
<p>In order for stauto32 to load a time provider plug-in, the plug-in must be signed with a certificate
that has a root that is in the trusted root store. Additionally, each plug-in requires a companion key-file.
This key-file has an extension of "rsap." To obtain this key-file from RSA Partner Engineering, follow this procedure:
<ol>
<li>Deliver a binary-encoded CER (x509) file or signed plug-in DLL/DYLIB to RSA Partner Engineering for certification. If you do not deliver the plug-in, you must supply the file name of the plug-in DLL/DYLIB that will be put into production. On Mac, you must submit a CER file.</li>
<li>Partner Engineering runs a utility written by RSA Development to create a companion file for the plug-in ("rsap" extension).</li>
<li>The companion "rsap" file is returned, and you must include it, along with the plug-in DLL/DYLIB, in the same directory.</li>
</ol></p>
<p>If a signing certificate is updated, you must generate a new "rsap" file for the plug-in to load.</p>
<p>For plug-ins on Mac OS X, you need an additional "cire" file. Contact RSA Partner Engineering to obtain a utility to generate
this companion file.</p>

<h3>Plug-in Registration</h3>
<p>Each plug-in must be registered in order to be loaded. You can register the plug-in manually by modifying
the registry directly (on Windows), or preferences files (on Mac OS X). Alternatively, you can use the RegisterRtpUtil command line 
utility or the RegisterRtpDll shared library, which are available from RSA Partner Engineering.</p>
<p>To manually register a time provider plug-in on Windows, add a new registry key named the plug-in GUID value (for example,
{afc19322-7536-494c-a2e7-d8565525621c}) to HKEY_LOCAL_MACHINE\\SOFTWARE\\RSA\\Software Token\\Library\\TimeProviders.
Inside that key, create a string value called "path" with an absolute path to the plug-in DLL.</p>
<p>To manually register a plug-in on Mac OS X, modify the file "com.rsa.Software Token\\Library.plist"
to include a new string value named "TimeProviders.<guid>.path," where <guid> is the plug-in GUID (for example,
{afc19322-7536-494c-a2e7-d8565525621c}). Set the value to the absolute path to the plug-in DYLIB.</p>

<HR>

COPYRIGHT (C) 2009-2015 EMC Corporation
All Rights Reserved

This software contains the intellectual property of EMC Corporation or is licensed to 
EMC Corporation from third parties. Use of this software and the intellectual property 
contained therein is expressly limited to the terms and conditions of the License
Agreement under which it is provided by or on behalf of EMC.

*/

#ifndef _RSA_TIME_PROVIDER
#define _RSA_TIME_PROVIDER

#ifdef RSA_PARTNER_TIME_PROVIDER_EXPORTS
   #if defined(__APPLE__) || defined(applec)
        #define RSA_PARTNER_TIME_PROVIDER_API __attribute__((visibility("default")))
    #else
        #define RSA_PARTNER_TIME_PROVIDER_API  __declspec(dllexport)
    #endif // APPLE
#else
    #if defined(__APPLE__) || defined(applec)
        #define RSA_PARTNER_TIME_PROVIDER_API
    #else
        #define RSA_PARTNER_TIME_PROVIDER_API  __declspec(dllimport)
    #endif // APPLE
#endif //RSA_PARTNER_TIME_PROVIDER_EXPORTS


namespace RSA
{
    namespace SecurID
    {
        /*! Time provider interface version */
        const unsigned int RSA_TIME_PROVIDER_VERSION = 1;

        /*! Length of a GUID (38 characters plus a null terminator) */
        const int RSA_TIME_PROVIDER_GUID_STRING_LENGTH = 39;

        /*! Enumerated type to denote either a success or failure error code. */
        enum RSA_TIME_PROVIDER_ERROR
        {
            RSA_TIME_PROVIDER_SUCCESS,      /*!< Success code. */
            RSA_TIME_PROVIDER_FAILURE       /*!< General error code. */
        };

        /*!
        *  \brief Interface used for time providers objects.
        *
        *   Time provider instances can be retrieved from RSA::SecurID::ITimeProviderLoader
        *   instances (which is available from the RSA_RTP_CreateProviderInstance() function).
        *   Instances are used to provide the current time used during tokencode generation.
        *   See RSA::SecurID::IRsaTokenProvider::GetCode() for details on using a time provider.
        */
        class ITimeProvider
        {
        private:
            /*! Private copy constructor to make the class non-copyable */
            ITimeProvider(ITimeProvider&);
            /*! Private equals-operator to make the class non-copyable */
            ITimeProvider& operator=(ITimeProvider&);

        protected:
            /*! Constructor */
            ITimeProvider(){}
            /*! Destructor */
            virtual ~ITimeProvider(){}

        public:
            /*!
            *   Retrieve the current time for tokencode generation.
            *  \param[out] currentTime The current time as the number of seconds that have
            *   passed since 1970-01-01T00:00:00, Coordinated Universal Time.
            *  \return Return RSA_TIME_PROVIDER_SUCCESS, or failure error code. Beware when
            *   returning failure, as this will cause tokencode generation to fail.
            */
            virtual RSA_TIME_PROVIDER_ERROR getTime(unsigned int& currentTime) = 0;

            /*!
            *   Retrieve the time provider's unique GUID identifier (DCE variant UUID) used for registration.
            *  \param[out] guid DCE variant UUID of the form "{c12eddc5-a914-42ae-bf3a-ad2df44ba85d}". The memory
            *   for guid will be allocated with an array of 39 characters (for GUID and null terminator),
            *   so the guid string can be copied in.
            *  \return Return RSA_TIME_PROVIDER_SUCCESS, or failure error code.
            */
            virtual RSA_TIME_PROVIDER_ERROR getGuid(char* guid) = 0;
        };

    } //end namespace SecurID
} //end namespace RSA


extern "C"
{
    /*!
    *  \brief This function is used for creating a new time provider (i.e. RSA::SecurID::ITimeProvider) instance.
    *
    *   It is recommended that the RSA::SecurID::ITimeProvider implementation use the Singleton design pattern.
    *
    *  \return Pointer to an instance of RSA::SecurID::ITimeProvider.
    */
    RSA_PARTNER_TIME_PROVIDER_API RSA::SecurID::ITimeProvider* RSA_CreateTimeProviderInstance();

    /*!
    *  \brief Function to delete the RSA::SecurID::ITimeProvider instance.
    *
    *   <b>Note:</b> Verify that instance was the same one retrieved
    *   from RSA_CreateTimeProviderInstance() before deleting it.
    *
    *  \param[in] instance Pointer to the RSA::SecurID::ITimeProvider instance.
    */
    RSA_PARTNER_TIME_PROVIDER_API void RSA_ReleaseTimeProviderInstance(RSA::SecurID::ITimeProvider* instance);

    /*!
    *  \brief Function to retrieve interface version.
    *
    *   This function should be implemented as shown:
    *  \code
    *       unsigned int RSA_GetTimeProviderVersion()
    *       {
    *           return RSA::SecurID::RSA_TIME_PROVIDER_VERSION;
    *       }
    *  \endcode
    *
    *  \return Always return RSA::SecurID::RSA_TIME_PROVIDER_VERSION.
    */
    RSA_PARTNER_TIME_PROVIDER_API unsigned int RSA_GetTimeProviderVersion();

}

#endif //_RSA_TIME_PROVIDER

