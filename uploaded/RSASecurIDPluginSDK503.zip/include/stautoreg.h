/*
 * COPYRIGHT (C) 2009-2015 EMC Corporation
 * ALL RIGHTS RESERVED.
 *  
 * This software contains the intellectual property of EMC Corporation 
 * or is licensed to EMC Corporation from third parties. Use of this software 
 * and the intellectual property contained therein is expressly limited 
 * to the terms and conditions of the License Agreement under which it is 
 * provided by or on behalf of EMC.  
 *   
 */

#ifndef STAUTOREG_H
#define STAUTOREG_H

#if defined(STAUTOREG_LIB)
    #if defined(__APPLE__) || defined(applec)
        #define STAUTOREG_EXPORT __attribute__((visibility("default")))
    #else 
        #define STAUTOREG_EXPORT __declspec(dllexport)
    #endif // APPLE
#else
     #if defined(__APPLE__) || defined(applec)
        #define STAUTOREG_EXPORT
    #else 
        #define STAUTOREG_EXPORT __declspec(dllimport)
    #endif // APPLE
#endif //STAUTOREG_LIB


extern "C" {

    /*!
    *   Function used to register a token plugin in the system scope
    *
    *  \param[in] path UTF-8 encoded absolute path to the shared library
    *  \param[in] systemScope Must set to true. A value of false is unsupported.
    *
    *  \return Returns a value of true if successfully registered, false otherwise
    */
	STAUTOREG_EXPORT bool Import(const char* path, bool systemScope);

    /*!
    *   Function used to unregister a token plugin from the system scope
    *
    *  \param[in] path UTF-8 encoded absolute path to the shared library
    *  \param[in] systemScope Must set to true. A value of false is unsupported.
    *
    *  \return Returns a value of true if successfully unregistered, false otherwise
    */
	STAUTOREG_EXPORT bool Remove(const char* path, bool systemScope);


    /*!
    *   Function used to register a time plugin in the system scope
    *
    *  \param[in] path UTF-8 encoded absolute path to the shared library
    *
    *  \return Returns a value of true if plugin was successfully registered, false otherwise
    */
	STAUTOREG_EXPORT bool RegisterTimePlugin(const char* const path);

    /*!
    *   Function used to unregister a time plugin in the system scope
    *
    *  \param[in] path UTF-8 encoded absolute path to the shared library
    *
    *  \return Returns a value of true if plugin was successfully unregistered, false otherwise
    */
	STAUTOREG_EXPORT bool UnregisterTimePlugin(const char* const path);
}

#endif // STAUTOREG_H
