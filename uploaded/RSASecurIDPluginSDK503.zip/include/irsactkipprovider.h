/*
 * COPYRIGHT (C) 2009-2010 RSA SECURITY INC.  ALL RIGHTS RESERVED.
 *  
 * THIS SOFTWARE IS PROPRIETARY AND CONFIDENTIAL TO RSA SECURITY INC.,        
 * IS FURNISHED UNDER A LICENSE AND MAY BE USED AND COPIED                    
 * ONLY IN ACCORDANCE THE TERMS OF SUCH LICENSE AND WITH THE INCLUSION           
 * OF THE ABOVE COPYRIGHT NOTICE.  THIS SOFTWARE OR ANY OTHER COPIES THEREOF  
 * MAY NOT BE PROVIDED OR OTHERWISE MADE AVAILABLE TO ANY OTHER PERSON.  NO   
 * TITLE TO AND OWNERSHIP OF THE SOFTWARE IS HEREBY TRANSFERRED.              
 *                                                                            
 * THE INFORMATION IN THIS SOFTWARE IS SUBJECT TO CHANGE WITHOUT NOTICE AND   
 * SHOULD NOT BE CONSTRUED AS A COMMITMENT BY RSA SECURITY INC.  
 */

#ifndef _RSA_CTKIP_PROVIDER
#define _RSA_CTKIP_PROVIDER

#include "rtpstring.h"
#include "rtptokendata.h"


namespace RSA
{
    namespace SecurID
    {
        namespace CTKIP
        {
            /*! Enumerated type for errors that can occur with CT-KIP */
            enum CTKIP_ERROR
            {
                CTKIP_SUCCESS,              /*!< Success code */
  				CTKIP_ERROR_FAILURE,        /*!< Generic error code */
  				CTKIP_ERROR_DEVICE_FULL,    /*!< Error that occurs when no additional tokens can be imported to the device */
  				CTKIP_ERROR_OPERATION_NOT_SUPPORTED,    /*!< Error indicating that a particular operation is not supported by the device */
  				CTKIP_ERROR_NO_KEY,         /*!< Error indicating that the server did not send an encryption key */
  				CTKIP_ERROR_NO_MAC,         /*!< Error indicating that the server did not send a MAC */
  				CTKIP_ERROR_BAD_MAC,        /*!< Error that occurs when the server MAC validation fails */
  				CTKIP_ERROR_BAD_RANDOM,     /*!< Error that occurs when the client fails to generate random data */
  				CTKIP_ERROR_NO_MEMORY,      /*!< Error indicating that memory allocation failed */
  				CTKIP_ERROR_BAD_NONCE,      /*!< Error indicating that the client received a bad server nonce */
  				CTKIP_ERROR_BAD_PACKET,     /*!< Error that occurs when the client receives a bad packet from the server that it could not parse */
  				CTKIP_ERROR_COMM,           /*!< Error indicating that there was a communication error (for example, failing to send a packet) */
  				CTKIP_ERROR_UNKNOWN,        /*!< Unknown error */
  				CTKIP_PROCESSOR_MISSING,    /*!< Error indicating that there is a missing CT-KIP processor in the processor chain */
  				CTKIP_ERROR_UNTRUSTED_CERT  /*!< Error indicating SSL certificate is untrusted */
            };

            /*! Enumerated type denoting the MAC type used for CT-KIP */
            enum CTKIP_MAC_TYPE
            {
                TYPE_ONE,   /*!< AES */
                TYPE_TWO    /*!< Currently never used, reserved */
            };

            /*!
            *  \brief Optional interface used for on-device CT-KIP.
            *
            *   An object implementing this interface should be returned by
            *   RSA::SecurID::IRsaTokenProvider::GetCtkipProvider() if the token storage device supports on-device CT-KIP.
            *   Use this only if it is important that the token seed be generated directly on the
            *   device hardware instead of being passed down to it during the import process.
            */
            class IRsaCtkipProvider
            {
            public:
                /*! Destructor */
                virtual ~IRsaCtkipProvider(){}

                /*!
                *  \brief Optional. Function used to retrieve the activation code data.
                *
                *   This function will only be called if RSA::SecurID::DeviceInfo::getSupportedDirectInputs()
                *   supports DIRECT_INPUT_ACTIVATION_CODE. Most token storage devices do not support this
                *   functionality. The function will be called before GetProvisioningData() when
                *   the direct input is supported.
                *
                *  \param[out] activationData Activation code data
                *  \return CTKIP_SUCCESS if activationData is set, CTKIP_ERROR_OPERATION_NOT_SUPPORTED if not supported
                */
                virtual CTKIP_ERROR GetActivationData(RtpString<> &activationData)
                {
                    return CTKIP_ERROR_OPERATION_NOT_SUPPORTED;
                }

                /*!
                *   Optional. First function called during the CT-KIP process. Retrieves provisioning data to be passed to the server.
                *  \param[in] activationCode Activation code
                *  \param[out] provisioningData Custom provisioning data
                *  \return CTKIP_SUCCESS if provisioningData is set, CTKIP_ERROR_OPERATION_NOT_SUPPORTED if not supported
                */
                virtual CTKIP_ERROR GetProvisioningData(const RtpString<> &activationCode,
                    RtpString<> &provisioningData)
                {
                    return CTKIP_ERROR_OPERATION_NOT_SUPPORTED;
                }

                /*!
                *   Second step of the CT-KIP process involving client nonce generation and encryption.
                *  \param[in] serverPubKey The server public key
                *  \param[out] encryptedClientNonce The generated client nonce encrypted with the server public key
                *  \param[in/out] provisioningData Optional. Provisioning data from server passed in, custom provisioning data to server passed out.
                *  \return Error code or CTKIP_SUCCESS when successful.
                */
                virtual CTKIP_ERROR CreateToken(const RtpString<CK_BYTE> &serverPubKey,
                    RtpString<CK_BYTE> &encryptedClientNonce,
                    RtpString<> &provisioningData) = 0;

                /*!
                *  \brief Final step of the CT-KIP process.
                *
                *   In this function, the MAC value should be computed, the server MAC should be verified, and the token
                *   seed and attribute data should be committed to persistant storage.
                *
                *  \param[in] macType The type of MAC
                *  \param[in] serverMac Server MAC value
                *  \param[in] serverRandom Random key data from the server
                *  \param[in] tokenData Token attribute metadata
                *  \param[in] provisioningData Provisioning data from the server
                *  \return Error code or CTKIP_SUCCESS when successful.
                */
                virtual CTKIP_ERROR VerifyMacAndActivateToken(CTKIP_MAC_TYPE macType,
                    const RtpString<CK_BYTE> &serverMac,
                    const RtpString<CK_BYTE> &serverRandom,
                    const RsaTokenData &tokenData,
                    const RtpString<> &provisioningData) = 0;

                /*!
                *   Function called when the CT-KIP process needs to be ended early.
                *  \return Error code or CTKIP_SUCCESS when successful.
                */
                virtual CTKIP_ERROR CancelCtkipProcess() = 0;
            };

        }
    }
}

#endif

