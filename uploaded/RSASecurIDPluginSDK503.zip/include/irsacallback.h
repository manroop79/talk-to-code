/*
COPYRIGHT (C) 2009-2015 EMC Corporation 
All Rights Reserved

This software contains the intellectual property of EMC Corporation or is licensed to 
EMC Corporation from third parties. Use of this software and the intellectual property 
contained therein is expressly limited to the terms and conditions of the License
Agreement under which it is provided by or on behalf of EMC. 
*/ 

#ifndef _I_RSA_CALLBACK_
#define _I_RSA_CALLBACK_

namespace RSA
{
    /*!
    *  \brief Callback class
    *
    *   Instances of this class are used for device insertion and removal events (with the instance
    *   passed into RSA_RTP_GetDllInfo()) and token change events (with the instance passed into
    *   RSA_RTP_CreateProviderInstance()).
    */
    class IRsaCallback
    {
		public:
			/*!
			*  \brief Used to trigger a callback event.
            *
            *   For example, if "callback" is a pointer to an RSA::IRsaCallback instance, triggering
            *   a device connection event would be done in the following way:
            *
            *  \code
            *       int param = RTP_CALLBACK_DEVICE_CONNECT;
            *       if (callback) {
            *           callback->Execute(&param);
            *       }
            *  \endcode
            *
			*  \param[in] Param Pointer to an int with a value of RTP_CALLBACK_DEVICE_CONNECT or
            *   RTP_CALLBACK_DEVICE_DISCONNECT (for device events) or RTP_CALLBACK_TOKEN_REFRESH (for
            *   token modification events).
            *
			*  \return Returns boolean denoting whether execution succeeds or fails.
			*/
            virtual bool Execute(void *Param) const = 0;

#if defined(__APPLE__) || defined(applec)
            virtual ~IRsaCallback() { }
#endif
    };
}

#endif

