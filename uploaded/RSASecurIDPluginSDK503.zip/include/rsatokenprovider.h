/*! \mainpage RSA Token Provider Interface 2.0

<img src="architecture.png" alt="Architecture" align="left">
<p>The RSA Token Provider (RTP) Interface is used by RSA and its partners to create
token provider plug-ins for use with the RSA SecurID Software Token 4.x and 5.0 applications.
The plug-ins are responsible for managing one or more "token storage devices" which will
be used for storage of token metadata (including all attributes and the seed value) and
tokencode generation. The underlying architecture of this design is that plug-ins
(implemented as DLLs on Windows and dylibs on Mac) manage devices, and devices manage tokens.
The RSA::SecurID::IRsaTokenProvider interface contains all of the functions a token storage
device is responsible for.</p>
<p>Each plug-in and token storage device has unique identifiers referred to as GUIDs.
The GUIDs are DCE variant UUIDs. They can be generated in many different ways.
(One method is to use the RegisterRtpUtil utility available from RSA Partner Engineering.)
Three unique GUIDs are used:
<ul>
<li>Token Storage Device GUID - returned by the function RSA::SecurID::DeviceInfo::getDeviceGuid().
It is used to uniquely identify a device. If multiple devices will be used on the same computer,
they must have different GUIDs.</li>
<li>Device Class GUID - returned by the function RSA::SecurID::DeviceInfo::getDeviceClassGuid().
This GUID will be shared among all devices that have the same security characteristics.</li>
<li>Plug-in GUID - returned by the function RSA::SecurID::DllInfo::getDllGuid(). It is used
for plug-in registration.</li>
</ul>
These GUIDs will be used by the stauto32 library to differentiate between the plug-ins and token
storage devices. Another form of identification used for token storage devices is the
"device serial number" used in the function RSA::SecurID::DeviceInfo::getDeviceSerialNumber(). The device serial number
also uniquely identifies a device, although it does not need to be a DCE UUID. While a device GUID
can be hardcoded to use the same one on different computers, the device serial number must be
globally unique. If a unique value cannot be found, none should be used.</p>
<p><b>Important:</b> Strings are UTF-8 encoded.</p>

<h2>How the Plug-in Will Be Used</h2>
<p>Each plug-in must export the following C-style functions:
<ul>
<li>RSA_RTP_SetAllocator() - Used to properly handle memory allocation and deallocation for all strings used.</li>
<li>RSA_RTP_GetVersion() - Used to determine which version of the RTP interface the plug-in is using.</li>
<li>RSA_RTP_GetDllInfo() - Used to retrieve the RSA::SecurID::DllInfo plug-in information, including the plug-in GUID.</li>
<li>RSA_RTP_ReleaseDllInfoInstance() - Used to signal that the object returned above should be deallocated.</li>
<li>RSA_RTP_CreateProviderInstance() - Used to create a token storage device instance. It will be called multiple times if there are multiple devices.</li>
<li>RSA_RTP_ReleaseProviderInstance() - Used to signal that one token storage device instance should be destroyed.</li>
</ul></p>
<p>For each registered plug-in, the stauto32 library will begin by calling RSA_RTP_SetAllocator(),
RSA_RTP_GetVersion(), and RSA_RTP_GetDllInfo() in that order. Using the RSA::SecurID::DllInfo instance
returned from RSA_RTP_GetDllInfo(), the stauto32 library will iterate over it to retrieve all of the
active token storage devices (RSA::SecurID::DeviceInfo objects). For each device, the stauto32 library
will pass the device GUID to RSA_RTP_CreateProviderInstance() to create a "token provider" (a
RSA::SecurID::IRsaTokenProvider object) for that device. The stauto32 library will then iterate over that
object to get token attribute information (RSA::SecurID::RsaTokenData objects) for each token
stored on the device. Token and device metadata must be publicly available without device login
(opening a protected session) for an optimal user experience.</p>

<h3>Protected Operations</h3>
<p>Certain operations in the RSA::SecurID::IRsaTokenProvider interface are considered "protected operations"
that should require authentication (for example, entering a password, verifying a biometric, and so on) on devices
that support it. These operations are protected because they involve either retrieving a tokencode or
performing a "write" operation. These operations include:
<ul>
<li>RSA::SecurID::IRsaTokenProvider::ImportToken()</li>
<li>RSA::SecurID::IRsaTokenProvider::DeleteToken()</li>
<li>RSA::SecurID::IRsaTokenProvider::SetTokenLabel()</li>
<li>RSA::SecurID::IRsaTokenProvider::GetCode()</li>
</ul></p>

<h3>Asynchronous Events</h3>
<p>The plug-in must notify the stauto32 library about certain events.
The following callbacks (instances of RSA::IRsaCallback) are provided to handle these events:
<ul>
<li>The callback passed into RSA_RTP_GetDllInfo() is used to notify stauto32 about device insertions
and removals. If there are no pluggable token storage devices, this callback should never be used.
After this is called, stauto32 will iterate over RSA::SecurID::DllInfo to retrieve the
RSA::SecurID::DeviceInfo objects again.</li>
<li>The callback passed into RSA_RTP_CreateProviderInstance() is used to notify the stauto32 library
that the state of one or more tokens has changed. This would most likely be used to notify that a change,
import, or delete operation occurred in another process. After this is called, stauto32 will iterate over
RSA::SecurID::IRsaTokenProvider to retrieve the RSA::SecurID::RsaTokenData objects again.</li>
</ul></p>
<p><b>Important:</b> The callbacks should never be executed in the same thread as other operations, as this
may result in deadlock.</p>

<h2>Development Instructions</h2>
<p>An example token provider plug-in (the files PartnerTokenProvider.h and
PartnerTokenProvider.cpp)is shipped with this SDK. The example may be useful as a starting point for new development. The example does
not persist any token data. Additionally, the GUID identifiers used in the
example must be replaced with new DCE variant UUIDs.</p>
<p><b>Important:</b>When testing your plug-in, it may be useful to unregister the "Local Hard Disk (RSA)"
plug-in, as its anti-debug/anti-attack features will not allow a debugger to be attached. You can unregister the plug-in
by using the RegisterRtpUtil utility available from RSA Partner Engineering.</p>

<h2>Plug-in Signing and Registration</h2>
<p>Each token provider plug-in must be digitally signed and registered.</p>
<h3>Plug-in Signature Process</h3>
<p>In order for stauto32 to load a plug-in, the plug-in must be signed with a certificate that has a root
that is in the trusted root store. Additionally, each plug-in requires a companion key-file. This key-file has
an extension of "rsap." To obtain this key file from RSA Partner Engineering, follow this procedure:
<ol>
<li>Deliver a binary-encoded CER (x509) file or signed plug-in DLL/DYLIB to RSA Partner Engineering for certification. If you do not deliver the plug-in, you must supply the file name of the plug-in DLL/DYLIB that will be put into production. On Mac, you must submit a CER file.</li>
<li>Partner Engineering runs a utility written by RSA Development to create a companion file for the plug-in ("rsap" extension).</li>
<li>The companion "rsap" file is returned, and you must include it, along with the plug-in DLL/DYLIB, in the same directory.</li>
</ol></p>
<p>If a signing certificate is updated, you must generate a new "rsap" file for the plug-in to load.</p>
<p>For plug-ins on Mac OS X, you need an additional "cire" file. Contact RSA Partner Engineering to obtain a utility to generate
this companion file.</p>

<h3>Plug-in Registration</h3>
<p>Each plug-in must be registered in order to be loaded. You can register the plug-in manually by modifying
the registry directly (on Windows), or preferences files (on Mac OS X). Alternatively, you can use the RegisterRtpUtil utility or
RegisterRtpDll shared library, which are available from RSA Partner Engineering.</p>
<p>To manually register a plug-in on Windows, add a new registry key named the plug-in GUID value (for example, {afc19322-7536-494c-a2e7-d8565525621c}) to HKEY_LOCAL_MACHINE\\SOFTWARE\\RSA\\Software Token\\Library\\Plugins.
Inside that key, create a string value called "path" with an absolute path to the plug-in DLL.</p>
<p>To manually register a plug-in on Mac OS X, modify the file "com.rsa.Software Token\\Library.plist"
to include a new string value named "Plugins.<guid>.path" where <guid> is the plug-in GUID (for example, {afc19322-7536-494c-a2e7-d8565525621c}). Set the value to the absolute path to the plug-in DYLIB.</p>

<HR>

COPYRIGHT (C) 2009-2015 EMC Corporation  
ALL RIGHTS RESERVED

This software contains the intellectual property of EMC Corporation or is licensed to 
EMC Corporation from third parties. Use of this software and the intellectual property 
contained therein is expressly limited to the terms and conditions of the License
Agreement under which it is provided by or on behalf of EMC.

*/

#ifndef _RSA_TOKEN_PROVIDER
#define _RSA_TOKEN_PROVIDER

#ifdef RSA_PARTNER_RTP_EXPORTS
   #if defined(__APPLE__) || defined(applec)
        #define RSA_PARTNER_RTP_API __attribute__((visibility("default")))
    #else
        #define RSA_PARTNER_RTP_API  __declspec(dllexport)
    #endif // APPLE
#else
    #if defined(__APPLE__) || defined(applec)
        #define RSA_PARTNER_RTP_API
    #else
        #define RSA_PARTNER_RTP_API  __declspec(dllimport)
    #endif // APPLE
#endif //RSA_PARTNER_RTP_EXPORTS


#include "irsacallback.h"
#include "itimeproviderloader.h"
#include "rtpstring.h"
#include "rtptokendata.h"
#include "irsactkipprovider.h"


namespace RSA
{
    namespace SecurID
    {
        /*! Interface version */
        const unsigned int RTP_VERSION = 2;


        /* ALL STRINGS EXCEEDING THE LENGTHS DEFINED BELOW WILL BE TRUNCATED */

        /*! The maximum number of bytes of a token seed */
        const int  RTP_TOKEN_SEED_MAX_BYTES = 16;
        /*! The RSA public key size used for encryption */
        const int RTP_RSA_PUBLIC_KEY_SIZE = 128;
        /*! Maximum serial number length, usually 12 digits */
        const int RTP_MAX_SERIAL_NUMBER_LENGTH = 32;
		/*! Maximum PIN length */
        const int RTP_MAX_PIN_LENGTH = 8;
		/*! Maximum token label/nickname length, usually 24 characters or less */
        const int RTP_MAX_TOKEN_LABEL_LENGTH = 32;
		/*! Maximum OTP tokencode length, usually 6 or 8 digits */
        const int RTP_MAX_OTP_CODE_LENGTH = 32;
		/*! Maximum string length */
        const int RTP_DEFAULT_MAX_STRING_LENGTH = 256;
		/*! Length of a GUID (38 characters plus a null terminator) */
        const int RTP_GUID_STRING_LENGTH = 39;
        /*! Maximum URL length */
        const int RTP_MAX_URL_LENGTH = 1024;
        /*! Maximum length of extended attributes XML data */
        const int RTP_MAX_EXTENDED_ATTRIBUTES_LENGTH = 2048;


        /*! Enumerated type to denote either success or a failure error code */
        enum RSA_RTP_ERR
        {
            RSA_RTP_SUCCESS=0,          /*!< Success code */
            RSA_RTP_FAILURE=10,         /*!< General error */
            RSA_RTP_DEVICE_LOGIN_REQUIRED=1,    /*!< Returned if device requires login */
            RSA_RTP_DEVICE_PIN_INVALID=2,       /*!< Returned if device login fails */
            RSA_RTP_DEVICE_FULL=3,      /*!< Indicates that device is full and no more tokens can be imported */
            RSA_RTP_TOKEN_READ_ONLY=4,          /*!< Error indicating that token storage device is read-only */
            RSA_RTP_DEVICE_MALFUNCTION=5,       /*!< Returned if device operation fails due to a hardware problem */
            RSA_RTP_OPERATION_NOT_SUPPORTED=6,  /*!< Error indicating that a particular operation is not supported by the device */
            RSA_RTP_ALGORITHM_NOT_SUPPORTED=7,  /*!< Returned from RSA::SecurID::IRsaTokenProvider::ImportToken() if the token
                                                    algorithm being imported is not supported by the device */
            RSA_RTP_DUPLICATE_SERIAL_NUMBER=8,  /*!< Error indicating that a token with this serial number has already been imported */
            RSA_RTP_TOKEN_SERIAL_NOT_FOUND=9,   /*!< Error indicating that the token serial number passed into the function is invalid */
            RSA_RTP_DEVICE_RESET=11,            /*!< Returned only when an operation occurred resulting in a device reset */
            RSA_RTP_TIME_PROVIDER_FAILURE=12    /*!< Error getting time from RSA::SecurID::ITimeProvider instance */
        };


        /*! Enumerated type denoting the current mode of the device */
        enum OPEN_MODE
        {
            MODE_READ,          /*!< Read-only mode. Typically used only with devices that do not allow write operations. */
            MODE_READ_WRITE     /*!< Read/Write mode. */
        };


        /*! Structure used to present information on the last error that occurred */
        struct ErrorInfo
        {
            int code;                   /*!< RSA_RTP_ERR error code */
            RtpString<> errorString;    /*!< Short description of error that occurred */
        };


        /*!
        *  \brief Information on one token storage device.
        *
        *   You must set this information correctly, as it will influence the way
        *   certain operations are handled.
        *
        *   Note: If multiple token storage devices will be used on the same computer,
        *   they must each have unique device GUIDs. See the introduction of the main page for more
        *   information on GUIDs.
        */
        class DeviceInfo
        {
        public:
            /* Bitmask flags */

            static const unsigned int TOKEN_TYPE_30SEC = 0x1;       /*!< Used with getSupportedTokenTypes() for support of 30 second intervals. */
            static const unsigned int TOKEN_TYPE_60SEC = 0x2;       /*!< Used with getSupportedTokenTypes() for support of 60 second intervals. */
            static const unsigned int TOKEN_TYPE_6DIGITCODE = 0x4;  /*!< Used with getSupportedTokenTypes() for support of 6 digit OTP lengths. */
            static const unsigned int TOKEN_TYPE_8DIGITCODE = 0x8;  /*!< Used with getSupportedTokenTypes() for support of 8 digit OTP lengths. */

            static const unsigned int PROVISION_SDTID_FILE = 0x1;   /*!< Used with getSupportedProvisioningMethods() for support of SDTID file imports. */
            static const unsigned int PROVISION_CTKIP = 0x2;        /*!< Used with getSupportedProvisioningMethods() for support of CT-KIP web imports. */

            static const unsigned int DIRECT_INPUT_PIN = 0x1;       /*!< Used with getSupportedDirectInputs() for support of direct PIN input. */
            static const unsigned int DIRECT_INPUT_ACTIVATION_CODE = 0x2;   /*!< Used with getSupportedDirectInputs() for support of direct activation code input. */

        public:
            /*! Destructor */
            virtual ~DeviceInfo(){}

            /*!
            *   Accessor for device name string.
            *  \return Device name.
            */
            virtual RtpString<> getVendorString()  const = 0;

            /*!
            *   Device version as a string of the form "a.b" or "a.b.c" or "a.b.c.d" where a, b, c, and d are integers.
            *  \return Version string.
            */
            virtual RtpString<> getVersionString() const = 0;

            /*!
            *   Accessor for major device release number.
            *  \return Major version number.
            */
            virtual unsigned int getVersionMajor()  const = 0;

            /*!
            *   Accessor for minor device release number.
            *  \return Minor version number.
            */
            virtual unsigned int getVersionMinor()  const = 0;

            /*!
            *  \brief Function to determine which tokencode generation algorithms are supported.
            *
            *   Typically, only RSA::SecurID::OtpAlgorithmType::RsaTotp128 will be set to true,
            *   indicating that only the 128-bit, time-based tokencode generation algorithm is supported.
            *
            *  \return All algorithms supported by the token storage device.
            */
            virtual const OtpAlgorithmType getAlgorithmType()  const = 0;

            /*!
            *  \brief Function to determine if token storage device is read-only or read/write.
            *
            *   Typically MODE_READ_WRITE should be returned; however MODE_READ should be returned
            *   if RSA::SecurID::IRsaTokenProvider::ImportToken(), RSA::SecurID::IRsaTokenProvider::DeleteToken(),
            *   and RSA::SecurID::IRsaTokenProvider::SetTokenLabel() are not supported.
            *
            *  \return Device mode.
            */
            virtual OPEN_MODE getOpenModeSupported()  const { return MODE_READ_WRITE; }

            /*!
            *  \brief Accessor for device GUID.
            *
            *   The GUID must be a DCE variant UUID (Universally Unique Identifier) and it should be formatted like
            *   "{c12eddc5-a914-42ae-bf3a-ad2df44ba85d}" with a null terminator.
            *
            *   Note: If multiple token storage devices will be used on the same computer,
            *   they must each have unique device GUIDs. This GUID must also be different from the device class GUID
            *   and the plug-in GUID. See the introduction of the main page for more information on GUIDs.
            *
            *  \return Device GUID identifier.
            */
            virtual const RtpString<char>  getDeviceGuid() const = 0;

            /*!
            *   Accessor for the maximum number of tokens that can be imported to the device.
            *  \return Maximum storage capacity for tokens on the device.
            */
            virtual unsigned int getMaxTokens()  const = 0;

            /*!
            *   Vendor-supplied device icon to be displayed in the UI.
            *  \return Raw device icon data.
            */
            virtual const RtpString<CK_BYTE> getIconData()  const = 0;

            /*!
            *   The type of icon returned by getIconData(). Currently only type 0 (PNG format) is supported.
            *  \return Device icon type.
            */
            virtual unsigned int getIconType() const { return 0; }

            /*!
            *  \brief Function to determine if token storage device supports getting the next tokencode immediately.
            *
            *   <b>Important:</b> Most token storage devices support getting the next tokencode immediately and should
            *   return a value of true. A value of false should only be returned when only the current code can be generated
            *   (for example, if the device is reliant on secure time on-board the device). Returning true allows for
            *   a better user experience.
            *
            *  \return Boolean value of true if next tokencode can be retrieved immediately, false otherwise.
            */
            virtual bool canGetNextCode() const = 0;

            /*!
            *   Function to determine if device is enabled. All devices should return true.
            *  \return Boolean value of true if device is enabled, false otherwise.
            */
            virtual bool isDeviceActivated() const { return true; }

            /*!
            *  \brief Accessor for device class GUID.
            *
            *   The GUID must be a DCE variant UUID (Universally Unique Identifier) and it should be formatted like
            *   "{c12eddc5-a914-42ae-bf3a-ad2df44ba85d}" with a null terminator.
            *
            *   This GUID will be shared among all devices of a specific class that have the same security characteristics.
            *   It must be different from the device class GUID and the plug-in GUID. See the introduction of the main page
            *   for more information on GUIDs.
            *
            *  \return Device class GUID identifier.
            */
            virtual const RtpString<char> getDeviceClassGuid() const = 0;

            /*!
            *  \brief Globally unique device serial number identifier.
            *
            *   The device serial number must uniquely identify the device (although it does not need to be a DCE UUID).
            *   While you can hardcode a device GUID to use the same one on different computers, the device serial number must be
            *   globally unique. If a unique value cannot be found, none should be used.
            *
            *  \return Device serial number string.
            */
            virtual const RtpString<> getDeviceVendorSerialNumber() const = 0;

            /*!
            *   Function to determine if secure time is available on-board device.
            *  \return Boolean value of true if time is available directly on device, false otherwise.
            */
            virtual bool isTimeAvailableOnDevice() const = 0;

            /*!
            *  \brief Function to determine if the token storage device supports setting a password (or setting a different authentication mechanism).
            *
            *   If a value of true is returned, the function RSA::SecurID::IRsaTokenProvider::SetDevicePassword()
            *   should not return RSA_RTP_OPERATION_NOT_SUPPORTED.
            *
            *  \return Return true if supported, false otherwise.
            */
            virtual bool canSetDevicePassword() const = 0;

            /*!
            *   Function to determine if the token storage provider stores token seeds directly on the hardware device.
            *  \return Return true if supported, false otherwise.
            */
            virtual bool isSeedStorageOnDevice() const = 0;

            /*!
            *   Function to determine if the token storage provider generates tokencodes in an external hardware processor.
            *  \return Return true if supported, false otherwise.
            */
            virtual bool isCodeGenerationOnDevice() const = 0;

            /*!
            *   Function to retrieve which token types are supported by the device. Typically, all token types are supported.
            *  \return Bitmask (TOKEN_TYPE_30SEC for 30-second tokens, TOKEN_TYPE_60SEC for 60-second tokens,
            *       TOKEN_TYPE_6DIGITCODE for 6-digit tokencodes, TOKEN_TYPE_8DIGITCODE for 8-digit tokencodes).
            */
            virtual unsigned int getSupportedTokenTypes() const
            {
                return (TOKEN_TYPE_30SEC | TOKEN_TYPE_60SEC | TOKEN_TYPE_6DIGITCODE | TOKEN_TYPE_8DIGITCODE);
            }

            /*!
            *   Function to get which data can be input directly by plug-in. Typically, plug-ins do not support direct input.
            *  \return Bitmask (DIRECT_INPUT_PIN for PIN, DIRECT_INPUT_ACTIVATION_CODE for activation code).
            */
            virtual unsigned int getSupportedDirectInputs() const { return 0x0; }

            /*!
            *   Function to retrieve supported provisioning methods. Typically, all provisioning methods are supported.
            *  \return Bitmask (PROVISION_SDTID_FILE for SDTID files, PROVISION_CTKIP for CT-KIP).
            */
            virtual unsigned int getSupportedProvisioningMethods() const { return (PROVISION_SDTID_FILE | PROVISION_CTKIP); }
        };


        /*!
        *  \brief Plug-in information that is returned by RSA_RTP_GetDllInfo().
        *
        *   This class acts as an iterator for the token storage devices
        *   (the RSA::SecurID::DeviceInfo objects). For each of the token storage devices, the function
        *   RSA_RTP_CreateProviderInstance() will be called to create a corresponding instance of a
        *   RSA::SecurID::IRsaTokenProvider object.
        *
        *   If the plug-in supports pluggable devices, the RSA::IRsaCallback callback parameter passed into RSA_RTP_GetDllInfo()
        *   should be executed in a separate thread with a value of either RTP_CALLBACK_DEVICE_CONNECT or
        *   RTP_CALLBACK_DEVICE_DISCONNECT, corresponding to the operation that occurred. It will result in the DeviceInfo objects
        *   being iterated again.
        */
        class DllInfo : public RSA::Iterator<DeviceInfo>
        {
        public:
            /*! Destructor */
            virtual ~DllInfo(){}

            /*!
            *   Plug-in version as a string of the form "a.b" or "a.b.c" or "a.b.c.d" where a, b, c, and d are integers.
            *  \return Version string.
            */
            virtual const RtpString<>  getVersionString() const = 0;

            /*!
            *   Accessor for plug-in name string.
            *  \return Plug-in name.
            */
            virtual const RtpString<> getVendorString() const = 0;

            /*!
            *   Accessor for major plug-in release number.
            *  \return Major version number.
            */
            virtual unsigned int getVersionMajor()  const = 0;

            /*!
            *   Accessor for minor plug-in release number.
            *  \return Minor version number.
            */
            virtual unsigned int getVersionMinor()  const = 0;

            /*!
            *  \brief Accessor for plug-in GUID.
            *
            *   The GUID must be a DCE variant UUID (Universally Unique Identifier) and it should be formatted like
            *   "{c12eddc5-a914-42ae-bf3a-ad2df44ba85d}" with a null terminator.
            *
            *   This GUID is used for registration of the plug-in. It must be different from the device GUID and
            *   the device class GUID. See the introduction of the main page for more information on GUIDs.
            *
            *  \return Plug-in GUID identifier.
            */
            virtual const RtpString<char>  getDllGuid() const = 0;
        };



        /*!
        *  \brief Token provider interface for token management and token operations.
        *
        *   Each token storage device will have a separate "token provider" instance created for it using the
        *   function RSA_RTP_CreateProviderInstance(). This class acts
        *   as an iterator for the tokens (the RSA::SecurID::RsaTokenData objects) stored on the device.
        *
        *   If an event occurs in a different process or application that affects the state of any tokens stored on
        *   this token storage device, the RSA::IRsaCallback callback parameter passed into RSA_RTP_CreateProviderInstance()
        *   should be executed in a separate thread with a value of RTP_CALLBACK_TOKEN_REFRESH. It will result in the
        *   RsaTokenData objects being iterated again. The member variable m_callback should be set to
        *   that callback.
        */
        class  IRsaTokenProvider : public RSA::Iterator<RsaTokenData>
        {
        private:
            /*! Private copy constructor to make the class non-copyable */
            IRsaTokenProvider(IRsaTokenProvider&);
            /*! Private equals-operator to make the class non-copyable */
            IRsaTokenProvider& operator=(IRsaTokenProvider&);

        protected:
            /*! Constructor that initializes member variables to 0 */
            explicit IRsaTokenProvider() : m_callback(0), m_ctkipProvider(0) {}
            /*! Destructor */
            virtual ~IRsaTokenProvider() {}

        public:
            /*!
            *  \brief Optional. This function is called when the device is not enabled and the user requests that the device be activated.
            *
            *   Currently, enabling devices using this function is not supported.
            *
            *   Note: A device is only considered not enabled if RSA::SecurID::DeviceInfo::isDeviceActivated()
            *   returns a value of false, but all devices should return true.
            *
            *  \return Should return RSA_RTP_SUCCESS or RSA_RTP_FAILURE only.
            */
            virtual RSA_RTP_ERR ActivateDevice() { return RSA_RTP_SUCCESS; }

            /*!
            *  \brief Optional. This function is called when the device is enabled and the user requests that the device be deactivated.
            *
            *   Currently, disabling devices using this function is not supported.
            *
            *   Note: A device is considered enabled if RSA::SecurID::DeviceInfo::isDeviceActivated()
            *   returns a value of true, which all devices should do.
            *
            *  \return Should return RSA_RTP_SUCCESS or RSA_RTP_FAILURE only.
            */
            virtual RSA_RTP_ERR DeactivateDevice() { return RSA_RTP_FAILURE; }

            /*!
            *  \brief Optional. This function is called once in the beginning for any device initialization that is needed.
            *
            *   This function is called first before any others, including OpenProtectedSession(). If device is
            *   not ready and returns an error, then this function will not be called again until m_callback
            *   is executed with a value of RTP_CALLBACK_TOKEN_REFRESH.
            *
            *  \param[in] mode Either "read-only" or "read/write"
            *  \return Return RSA_RTP_SUCCESS or an error code if the device is not ready or the mode is not allowed.
            */
            virtual RSA_RTP_ERR Open(OPEN_MODE mode) { return RSA_RTP_SUCCESS; }

            /*!
            *  \brief Optional. This function is called once at the end to close the device.
            *
            *   This function is called last, just before the provider instance is released with
            *   RSA_RTP_ReleaseProviderInstance().
            */
            virtual void Close() {  }

            /*!
            *   Used to retrieve the number of tokens imported to the token storage device.
            *  \param[out] count The number of installed tokens (size_t is a 32-bit unsigned integer, which is generally an unsigned int).
            *  \return Return RSA_RTP_SUCCESS or the relevant error code.
            */
            virtual RSA_RTP_ERR GetTokenCount(size_t & count) const  = 0;

            /*!
            *  \brief Protected operation. Used to retrieve the current or next tokencode for the selected token.
            *
            *   When next is set to a value of false, the current tokencode should be generated. When next is set
            *   to a value of true, the next tokencode should be generated. If this device does not support retrieving
            *   the next tokencode immediately (when the corresponding device's function RSA::SecurID::DeviceInfo::canGetNextCode()
            *   returns a value of false, which should only happen on certain hardware devices), this function should
            *   block until the next tokencode is available.
            *
            *   Unless secure time is available (when RSA::SecurID::DeviceInfo::isTimeAvailableOnDevice() returns true),
            *   a "time provider" (RSA::SecurID::ITimeProvider) must be used to retrieve the time to generate the tokencode.
            *   The time can be retrieved from the RSA::SecurID::ITimeProviderLoader passed into the function
            *   RSA_RTP_CreateProviderInstance() as follows:
            *  \code
            *       RSA::SecurID::RSA_TIME_PROVIDER_ERROR err = RSA::SecurID::RSA_TIME_PROVIDER_FAILURE;
            *       unsigned int currentTime = 0;
            *       RSA::SecurID::ITimeProvider* timeProvider = 0;
            *
            *       // timeProviderLoader is a parameter passed into RSA_RTP_CreateProviderInstance()
            *       RSA::SecurID::ITimeProviderLoader* tpl = timeProviderLoader;
            *
            *       if (tpl) {
            *           timeProvider = tpl->getTimeProvider();
            *           if (timeProvider) {
            *               err = timeProvider->getTime(currentTime);
            *           }
            *       }
            *
            *       // check for failure, otherwise currentTime should be all set to use
            *       if (err != RSA::SecurID::RSA_TIME_PROVIDER_SUCCESS || currentTime == 0) {
            *           return RSA::SecurID::RSA_RTP_TIME_PROVIDER_FAILURE;
            *       }
            *  \endcode
            *
            *   To calculate the value for timeRemaining, the token interval must be used. The following is an example
            *   of how timeRemaining can be set:
            *  \code
            *       RSA::SecurID::RsaTokenData* currentToken = 0;
            *       unsigned int currentTime = 0;
            *           ...     // set currentToken based on serial and currentTime using the time provider unless secure time is available
            *       unsigned int interval = currentToken->getOtpInterval();
            *       timeRemaining = interval - (currentTime % interval);
            *  \endcode
            *
            *   If the current time is after the token's expiration date (which can be retrieved from
            *   RSA::SecurID::RsaTokenData::getDeathDate()), the function should return a failure and not retrieve the tokencode.
            *
            *   If using the rsaotp library to generate tokencodes, be sure to use only the right-most
            *   8 digits of the token serial number (for example, only use "56789012" from a serial number such as "123456789012")
            *   along with the seed value and current time. Also be sure to pad correctly for serial numbers with fewer
            *   than 8 digits, such as "000000123456".
            *
            *   <b>Note:</b> This is a protected operation, so if OpenProtectedSession() has not been called yet, the error
            *   RSA_RTP_DEVICE_LOGIN_REQUIRED should be returned.
            *
            *  \param[in] serial Serial number of the selected token.
            *  \param[in] pin Can be ignored, as it is never used.
            *  \param[out] code Fill in with the tokencode.
            *  \param[out] timeRemaining Time left in seconds before next code is ready, set to -1 if time not available (for example, for some hardware devices).
            *  \param[in] next Will be set to true for the next tokencode, false for the current tokencode.
            *  \return Return RSA_RTP_SUCCESS or the relevant error code.
            */
            virtual RSA_RTP_ERR GetCode(
                const RtpString<> &serial,
                const RtpString<> &pin,
                int &timeRemaining,
                RtpString<> &code,
                bool next = false) = 0;

            /*!
            *  \brief Protected operation. This function is used to persist the token information to the token storage device.
            *
            *   Both the token seed and all of the token attribute data must be persisted. If no token label/nickname is specified
            *   (the size of RSA::SecurID::RsaTokenData::getTokenLabel() is 0), do not set the label to any default value.
            *
            *   When this function is called, you must verify that the token storage device supports the
            *   interval, number of digits, and algorithm of importData (importData.getOtpInterval(), importData.getOtpDigits(),
            *   and importData.getAlgorithmType()). The token storage device's capabilities should be available to the stauto32 library
            *   via the functions RSA::SecurID::DeviceInfo::getSupportedTokenTypes() and RSA::SecurID::DeviceInfo::getAlgorithmType().
            *   If importData is not supported, the error RSA_RTP_ALGORITHM_NOT_SUPPORTED should be returned.
            *
            *   If GetRsaPublicKey() does not return RSA_RTP_OPERATION_NOT_SUPPORTED, the token seed available via
            *   importData.getSeed() will be encrypted with the token storage device's public key and must be decrypted
            *   with the private key (PKCS padding is used). Otherwise, the seed is unencrypted.
            *
            *   <b>Note:</b> This is a write operation, so Open() should have been successfully called before this with the value
            *   MODE_READ_WRITE. If Open() was not called, return the error RSA_RTP_TOKEN_READ_ONLY.
            *
            *   <b>Note:</b> This is a protected operation, so if OpenProtectedSession() has not been called yet, the error
            *   RSA_RTP_DEVICE_LOGIN_REQUIRED should be returned.
            *
            *  \param[in] importData Token data that must be persisted to the device.
            *  \return Return RSA_RTP_SUCCESS or the relevant error code.
            */
            virtual RSA_RTP_ERR ImportToken(const RsaTokenImportData &importData) = 0;

            /*!
            *  \brief Protected operation. This function is used to remove the token specified by serial from persistent storage.
            *
            *   <b>Note:</b> This is a write operation, so Open() should have been successfully called before this with the value
            *   MODE_READ_WRITE. If Open() was not called, return the error RSA_RTP_TOKEN_READ_ONLY.
            *
            *   <b>Note:</b> This is a protected operation, so if OpenProtectedSession() has not been called yet, the error
            *   RSA_RTP_DEVICE_LOGIN_REQUIRED should be returned.
            *
            *  \param[in] serial Token serial number.
            *  \return Return RSA_RTP_SUCCESS or the relevant error code.
            */
            virtual RSA_RTP_ERR DeleteToken(const RtpString<> &serial) = 0;

            /*!
            *   Details about the last error that occurred.
            *  \param[out] info Description of the last error.
            */
            virtual void GetLastError(ErrorInfo &info) = 0;

            /*!
            *  \brief Authenticates the user for a protected session on the device.
            *
            *   This function will be called before doing any "protected operations" including
            *   ImportToken(), DeleteToken(), SetTokenLabel(), and GetCode(). It is the responsibility of this
            *   function to display any UI for getting credentials (for example, a password prompt or instructions for
            *   authenticating with a biometric). Return RSA_RTP_SUCCESS if authentication succeeds (or logging
            *   into the device is not necessary), or the error RSA_RTP_DEVICE_PIN_INVALID if login fails.
            *
            *   This function (and CloseProtectedSession()) may be called multiple times between the times when
            *   Open() and Close() are called. The user should be prompted to authenticate only the first time
            *   this function is successfully called.
            *
            *  \return Return RSA_RTP_SUCCESS or the relevant error code.
            */
            virtual RSA_RTP_ERR OpenProtectedSession() = 0;

            /*!
            *  \brief Closes the current protected session on the device.
            *
            *   No protected operations should be allowed until OpenProtectedSession() is called again.
            *
            *   This function (and OpenProtectedSession()) may be called multiple times between the times when
            *   Open() and Close() are called. The user should be prompted to authenticate in OpenProtectedSession()
            *   only the first time this function is successfully called.
            */
            virtual void CloseProtectedSession() = 0;

            /*!
            *  \brief Optional. Sets the protection for the device.
            *
            *   This function may be used to set up protection for the device if no protection has been set up.
            *   For example, a user could register a biometric or change their password. This function is responsible
            *   for displaying any necessary UI for this operation. If this function is not supported,
            *   the error RSA_RTP_OPERATION_NOT_SUPPORTED can be returned.
            *
            *  \return Return RSA_RTP_SUCCESS or the relevant error code.
            */
            virtual RSA_RTP_ERR SetDevicePassword() = 0;

            /*!
            *  \brief Optional. If device supports on-board CT-KIP, this function is used to access an RSA::SecurID::CTKIP::IRsaCtkipProvider implementation.
            *
            *   This function should return a pointer to a RSA::SecurID::CTKIP::IRsaCtkipProvider implementation (m_ctkipProvider)
            *   only when it is important that the token seed be generated directly on the token storage device hardware.
            *   Otherwise 0 can be returned and all CT-KIP operations will be handled by the stauto32 library.
            *
            *  \return RSA::SecurID::CTKIP::IRsaCtkipProvider pointer or 0 if not supported.
            */
            virtual RSA::SecurID::CTKIP::IRsaCtkipProvider* GetCtkipProvider() { return m_ctkipProvider; }

            /*!
            *  \brief Optional. Provides access to an RSA public key for the token storage device.
            *
            *   This function is called before ImportToken() to obtain a public key that the token
            *   seed will be encrypted with. If RSA_RTP_OPERATION_NOT_SUPPORTED is returned, the token
            *   seed is passed to ImportToken() in an unencrypted state.
            *
            *   The public key should be BER encoded, and the public key operations will use PKCS padding.
            *
            *  \param[out] key The public key of the token storage device used during the import token operation.
            *  \return Return RSA_RTP_SUCCESS or the relevant error code.
            */
            virtual RSA_RTP_ERR GetRsaPublicKey(RtpString<CK_BYTE> &key) = 0;

            /*!
            *  \brief Change the token label/nickname of a token.
            *
            *   The new token label that is set should replace the previous one set during ImportToken() in persistent
            *   storage and in the tokens available when iterating over this class.
            *
            *   <b>Note:</b> This is a write operation, so Open() should have been successfully called before this with the value
            *   MODE_READ_WRITE. If Open() was not called, return the error RSA_RTP_TOKEN_READ_ONLY.
            *
            *   <b>Note:</b> This is a protected operation, so if OpenProtectedSession() has not been called yet, the error
            *   RSA_RTP_DEVICE_LOGIN_REQUIRED should be returned.
            *
            *  \param[in] tokenSerial Selected token's serial number.
            *  \param[in] label New token label/nickname.
            *  \return Return RSA_RTP_SUCCESS or the relevant error code.
            */
            virtual RSA_RTP_ERR SetTokenLabel(const RtpString<>&tokenSerial, const RtpString<>&label ) = 0;

        protected:
            /*!
            *  \brief Member variable used for refresh callbacks.
            *
            *   It should be set during construction to the RSA::IRsaCallback passed into RSA_RTP_CreateProviderInstance().
            *   The callback should be executed in a separate thread from other token operations with a value of
            *   RTP_CALLBACK_TOKEN_REFRESH only when an event occurs in a different process or application that affects
            *   the state of any tokens stored on this token storage device.
            */
            RSA::IRsaCallback* m_callback;

            /*!
            *  \brief This should be set to an instance of RSA::SecurID::CTKIP::IRsaCtkipProvider or 0 if on-device CT-KIP is not supported.
            *
            *   See GetCtkipProvider() for details.
            */
            RSA::SecurID::CTKIP::IRsaCtkipProvider* m_ctkipProvider;
        };

    } //end namespace SecurID
} //end namespace RSA



// Extern C is included here because some platforms do not support C++ style library exports
extern "C"
{
    /*! Code used with RSA::IRsaCallback in RSA::SecurID::IRsaTokenProvider to force a refresh of all tokens on a device. */
    const int RTP_CALLBACK_TOKEN_REFRESH = 1;
    /*! Code used with RSA::IRsaCallback in RSA::SecurID::DllInfo when a pluggable device is disconnected. RSA::SecurID::IRsaTokenProvider::Close() will not be called. */
    const int RTP_CALLBACK_DEVICE_DISCONNECT = 2;
    /*! Code used with RSA::IRsaCallback in RSA::SecurID::DllInfo when a new pluggable device is connected. */
    const int RTP_CALLBACK_DEVICE_CONNECT = 3;

    /*!
    *  \brief Function used to retrieve the plug-in information.
    *
    *   When the RSA::SecurID::DllInfo object is retrieved, it will be iterated over to retrieve
    *   RSA::SecurID::DeviceInfo objects for all active token storage devices. For each device
    *   GUID (available from RSA::SecurID::DeviceInfo::getDeviceGuid()), a call to
    *   RSA_RTP_CreateProviderInstance() will be made that should each return a separate instance
    *   of RSA::SecurID::IRsaTokenProvider.
    *
    *   If the plug-in supports pluggable devices, the callback parameter should be used with
    *   the RSA::SecurID::DllInfo instance any time a device is connected or disconnected.
    *   The callback should be executed in a separate thread with a value of RTP_CALLBACK_DEVICE_CONNECT
    *   when a device is connected and a value of RTP_CALLBACK_DEVICE_DISCONNECT when a device is disconnected.
    *   Both will force an iteration of the RSA::SecurID::DeviceInfo objects for all token storage
    *   devices from the RSA::SecurID::DllInfo instance.
    *
    *  \param[in] callback Callback pointer for pluggable device connection and disconnection events (may possibly be 0).
    *  \return Pointer to instance of RSA::SecurID::DllInfo.
    */
    RSA_PARTNER_RTP_API RSA::SecurID::DllInfo* RSA_RTP_GetDllInfo(RSA::IRsaCallback *callback);

    /*!
    *  \brief Function to delete the RSA::SecurID::DllInfo instance.
    *
    *   <b>Note:</b> Verify if the instance was the same one retrieved
    *   from RSA_RTP_GetDllInfo() before deleting it. Possibly check the RSA::SecurID::DllInfo::getDllGuid()
    *   value.
    *
    *  \param[in] instance Pointer to the RSA::SecurID::DllInfo instance.
    */
    RSA_PARTNER_RTP_API void RSA_RTP_ReleaseDllInfoInstance(RSA::SecurID::DllInfo* instance);

    /*!
    *  \brief This function is called to create a "token provider" instance (i.e. an RSA::SecurID::IRsaTokenProvider instance) for a specific token storage device.
    *
    *   This function will be called once for each token storage device (the guid parameter passed
    *   into this function will identify which one), and each device should return a separate instance
    *   of RSA::SecurID::IRsaTokenProvider. It is recommended that if there is only one token storage device,
    *   the RSA::SecurID::IRsaTokenProvider implementation should follow the Singleton design pattern.
    *
    *   The callback parameter should be passed to the implementation of RSA::SecurID::IRsaTokenProvider
    *   when it is being constructed (m_callback should be set to it). It should be used to notify stauto32
    *   anytime an event occurs in another process/application that influences the state of the tokens
    *   stored on the device. It should not be used when a change occurs in the current process.
    *
    *   The callback should be executed in a separate thread with a value of RTP_CALLBACK_TOKEN_REFRESH,
    *   which will force an iteration of the RSA::SecurID::RsaTokenData objects for all tokens stored
    *   in the token storage device. An example of how to use it is as follows:
    *  \code
    *       int param = RTP_CALLBACK_TOKEN_REFRESH;
    *       if (callback) {
    *           callback->Execute(&param);
    *       }
    *  \endcode
    *
    *   The timeProviderLoader should also be passed to the implementation of RSA::SecurID::IRsaTokenProvider unless
    *   secure time is available on the hardware of the token storage device (see RSA::SecurID::DeviceInfo::isTimeAvailableOnDevice()).
    *   The "time provider" that can be retrieved will be used when generating tokencodes. See RSA::SecurID::IRsaTokenProvider::GetCode()
    *   for more information.
    *
    *  \param[in] guid Device GUID (of the form "{c12eddc5-a914-42ae-bf3a-ad2df44ba85d}") identifying which token storage device to return an RSA::SecurID::IRsaTokenProvider instance for.
    *  \param[in] callback Callback pointer for token refresh events (may possibly be 0).
    *  \param[in] timeProviderLoader Loader pointer for time provider (may possibly be 0).
    *  \return Pointer to a token provider instance for the device identified by the guid parameter.
    */
    RSA_PARTNER_RTP_API RSA::SecurID::IRsaTokenProvider* RSA_RTP_CreateProviderInstance(const char* guid,RSA::IRsaCallback *callback, RSA::SecurID::ITimeProviderLoader* timeProviderLoader);

    /*!
    *  \brief Function to delete the RSA::SecurID::IRsaTokenProvider instance.
    *
    *   <b>Note:</b> Verify if instance was the same one retrieved
    *   from RSA_RTP_CreateProviderInstance() before deleting it.
    *
    *  \param[in] instance Pointer to the RSA::SecurID::IRsaTokenProvider instance.
    */
    RSA_PARTNER_RTP_API void RSA_RTP_ReleaseProviderInstance(RSA::SecurID::IRsaTokenProvider* instance);

    /*!
    *  \brief Function to set the allocator and deallocator for RSA::SecurID::RtpString.
    *
    *   This is the first function that is called after loading plug-in shared library.
    *   You will need to implement the alloc and dealloc of RSA::SecurID::RtpString as shown below:
    *  \code
    *       typedef void* (*ALLOCATOR)(size_t);
    *       typedef void  (*DEALLOCATOR)(void*);
    *
    *       static ALLOCATOR g_alloc = 0;
    *       static DEALLOCATOR g_dealloc = 0;
    *
    *       void* RtpStringAllocator::alloc(size_t size)
    *       {
    *           if (g_alloc)
    *               return g_alloc(size);
    *           else
    *               return 0;
    *       }
    *
    *       void RtpStringAllocator::dealloc(void *p)
    *       {
    *           if (p && g_dealloc)
    *               g_dealloc(p);
    *       }
    *
    *       void RSA_RTP_SetAllocator(void *a, void* d)
    *       {
    *           g_alloc = (ALLOCATOR)a;
    *           g_dealloc = (DEALLOCATOR)d;
    *       }
    *  \endcode
    *
    *  \param[in] a Pointer to allocator.
    *  \param[in] d Pointer to deallocator.
    */
    RSA_PARTNER_RTP_API void RSA_RTP_SetAllocator(void *a, void *d);

    /*!
    *  \brief Function to retrieve interface version.
    *
    *   This function should be implemented as shown:
    *  \code
    *       unsigned int RSA_RTP_GetVersion()
    *       {
    *           return RSA::SecurID::RTP_VERSION;
    *       }
    *  \endcode
    *
    *  \return Always return RSA::SecurID::RTP_VERSION.
    */
    RSA_PARTNER_RTP_API unsigned int RSA_RTP_GetVersion();

}

#endif

