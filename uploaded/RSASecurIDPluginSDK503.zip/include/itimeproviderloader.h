/*
COPYRIGHT (C) 2009-2015 EMC Corporation 
All Rights Reserved

This software contains the intellectual property of EMC Corporation or is licensed to 
EMC Corporation from third parties. Use of this software and the intellectual property 
contained therein is expressly limited to the terms and conditions of the License
Agreement under which it is provided by or on behalf of EMC.
*/

#ifndef _I_TIME_PROVIDER_LOADER_
#define _I_TIME_PROVIDER_LOADER_

#include "rsatimeprovider.h"


namespace RSA
{
    namespace SecurID
    {
	    /*!
        *  \brief Loader class for RSA::SecurID::ITimeProvider instances.
        *
        *   Used with the function RSA_RTP_CreateProviderInstance() as a mechanism
        *   for plug-ins to retrieve "time providers" that will return the current time
        *   used for generating a tokencode.
        */
        class ITimeProviderLoader
        {
		    public:
			    /*! Destructor */
                virtual ~ITimeProviderLoader() {}

                /*!
                *   Function used to retrieve a time provider instance.
                *  \return Time provider pointer. This pointer should not be deallocated.
                */
                virtual ITimeProvider* getTimeProvider() = 0;
        };
    }
}

#endif //_I_TIME_PROVIDER_LOADER_

