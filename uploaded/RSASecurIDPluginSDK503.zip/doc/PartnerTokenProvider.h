/*
 * COPYRIGHT (C) 2009-2015 EMC Corporation
 * ALL RIGHTS RESERVED.
 *  
 * This software contains the intellectual property of EMC Corporation 
 * or is licensed to EMC Corporation from third parties. Use of this software 
 * and the intellectual property contained therein is expressly limited 
 * to the terms and conditions of the License Agreement under which it is 
 * provided by or on behalf of EMC.  
 *   
 */

#pragma once

#include <vector>
#include <map>
#include <string>
#include "rsatokenprovider.h"
#include "rsatimeprovider.h"

namespace RSA
{
    namespace SecurID
    {
        /*********************************************************************
            PartnerTokenInfo is a container class for your token meta-data
         **********************************************************************/

        class PartnerTokenInfo : public RsaTokenData
        {
        public:

            // Constructor - uses initialization list to set private member vars
            PartnerTokenInfo(const RsaTokenData &oldData) : 
                bShouldPrependPin(oldData.shouldPrependPin()),
                bIsPinrequired(oldData.isPinRequired()),
                icon(oldData.getIconData()),
                icon_type(oldData.getIconType()),
                url(oldData.getUrl()),
                startDate(oldData.getBirthDate()),
                endDate(oldData.getDeathDate()),
                serial(oldData.getSerialNumber()),
                otpInterval(oldData.getOtpInterval()),
                otpDigits(oldData.getOtpDigits()),
                userId(oldData.getUserId()),
                userFirstName(oldData.getUserFirstName()),
                userLastName(oldData.getUserLastName()),
                tokenLabel(oldData.getTokenLabel()),
                algorithmType(oldData.getAlgorithmType()),
                maxEventCount(oldData.getMaxEventCount()),
                extendedAttributes(oldData.getExtendedAttributes())
            {
            }

            // From RsaTokenData
            bool shouldPrependPin() const { return bShouldPrependPin; }
            const RtpString<CK_BYTE> getIconData() const { return icon; }
            unsigned int getIconType() const { return icon_type; }
            const CK_DATE getBirthDate() const { return startDate; }
            const RtpString<> getSerialNumber() const { return serial; }
            unsigned int getOtpInterval() const { return otpInterval; }
            unsigned int getOtpDigits() const { return otpDigits; }
            bool isPinRequired() const { return bIsPinrequired; }
            const RtpString<> getUrl() const { return url; }
            const RtpString<> getUserId() const { return userId; }
            const RtpString<>  getUserFirstName() const { return userFirstName; }
            const RtpString<>  getUserLastName() const { return userLastName; }
            const RtpString<>  getTokenLabel() const { return tokenLabel; }
            const CK_DATE getDeathDate() const { return endDate; }
            const OtpAlgorithmType getAlgorithmType() const { return algorithmType; }
            int getMaxEventCount() const { return maxEventCount; }
            const RtpString<> getExtendedAttributes() const { return extendedAttributes; }

        private:
            bool bShouldPrependPin; 
            bool bIsPinrequired;
            RtpString<CK_BYTE> icon;
            unsigned int icon_type;
            RtpString<> url;
            CK_DATE startDate;
            CK_DATE endDate;
            RtpString<> serial;
            unsigned int otpInterval; 
            unsigned int otpDigits;
            RtpString<> userId;
            RtpString<> userFirstName;
            RtpString<> userLastName;
            RtpString<> tokenLabel;
            OtpAlgorithmType algorithmType;
            int maxEventCount;
            RtpString<> extendedAttributes;
        };


         /*********************************************************************
            PartnerDeviceInfo is a container class for your device information
         **********************************************************************/

        class PartnerDeviceInfo : public DeviceInfo
        {
        public:

            // Constructor - uses initialization list to set private member vars
            PartnerDeviceInfo(
                const RSA::SecurID::OtpAlgorithmType alg,
                const RtpString<> &vend_str,
                const RtpString<> &ver_str,
                const RtpString<char> &guid,
                bool canGetNextCode,
                bool isActivated,
                unsigned int ver_maj,
                unsigned int ver_min,
                unsigned int max,
                const RSA::SecurID::OPEN_MODE mode,
                const RtpString<CK_BYTE> &icon_data,
                unsigned int icon_type,
                const RtpString<char> &class_guid,
                const RtpString<> &serial_number,
                bool timeAvailable,
                bool canSetPassword,
                bool seedStorage,
                bool codeGeneration,
                unsigned int tokenTypes,
                unsigned int directInputs,
                unsigned int provisioningMethods
                ) : 
                    m_vendorString(vend_str),
                    m_versionString(ver_str),
                    m_versionMajor(ver_maj),
                    m_versionMinor(ver_min),
                    m_algorithmType(alg),
                    m_openMode(mode),
                    m_deviceGuid(guid),
                    m_maxTokens(max),
                    m_iconData(icon_data),
                    m_iconType(icon_type),
                    m_nextCode(canGetNextCode),
                    m_activated(isActivated),
                    m_classGuid(class_guid),
                    m_serialNumber(serial_number),
                    m_timeAvailable(timeAvailable),
                    m_canSetPassword(canSetPassword),
                    m_seedStorage(seedStorage),
                    m_codeGeneration(codeGeneration),
                    m_tokenTypes(tokenTypes),
                    m_directInputs(directInputs),
                    m_provisioningMethods(provisioningMethods)
            {
            }

            // From DeviceInfo
            RtpString<> getVendorString()  const { return m_vendorString; }
            RtpString<> getVersionString() const { return m_versionString; }
            unsigned int getVersionMajor()  const { return m_versionMajor; }
            unsigned int getVersionMinor()  const { return m_versionMinor; }
            const OtpAlgorithmType getAlgorithmType()  const { return m_algorithmType; }
            OPEN_MODE getOpenModeSupported()  const { return m_openMode; }
            const RtpString<char>  getDeviceGuid() const { return m_deviceGuid; }
            unsigned int getMaxTokens()  const { return m_maxTokens; } 
            const RtpString<CK_BYTE> getIconData()  const { return m_iconData; }
            unsigned int getIconType() const { return m_iconType; }
            bool canGetNextCode() const { return m_nextCode; }
            bool isDeviceActivated() const { return m_activated; }
            const RtpString<char> getDeviceClassGuid() const { return m_classGuid; } 
            const RtpString<> getDeviceVendorSerialNumber() const { return m_serialNumber; }
            bool isTimeAvailableOnDevice() const { return m_timeAvailable; }
            bool canSetDevicePassword() const { return m_canSetPassword; }
            bool isSeedStorageOnDevice() const { return m_seedStorage; }
            bool isCodeGenerationOnDevice() const { return m_codeGeneration; }
            unsigned int getSupportedTokenTypes() const { return m_tokenTypes; }
            unsigned int getSupportedDirectInputs() const { return m_directInputs; }
            unsigned int getSupportedProvisioningMethods() const { return m_provisioningMethods; }
        
        private:
            RtpString<> m_vendorString;
            RtpString<> m_versionString;
            unsigned int m_versionMajor;
            unsigned int m_versionMinor;
            OtpAlgorithmType m_algorithmType;
            OPEN_MODE m_openMode;
            RtpString<char> m_deviceGuid;
            unsigned int m_maxTokens;
            RtpString<CK_BYTE> m_iconData;
            unsigned int m_iconType;
            bool m_nextCode;
            bool m_activated;
            RtpString<char> m_classGuid;
            RtpString<> m_serialNumber;
            bool m_timeAvailable;
            bool m_canSetPassword;
            bool m_seedStorage;
            bool m_codeGeneration;
            unsigned int m_tokenTypes;
            unsigned int m_directInputs;
            unsigned int m_provisioningMethods;
        };


         /*****************************************************************************************
            PartnerDllInfo is the class that implements interface to the devices inside the Dll
         ******************************************************************************************/

        class PartnerDllInfo : public RSA::SecurID::DllInfo
		{
        public:

            // PartnerDllInfo implements the Singleton design pattern
            // but it should additionally use mutexes to be thread safe
            static PartnerDllInfo* Instance(RSA::IRsaCallback *callback)
            {
                m_instance_count++;
                if (m_pinstance == 0)  // check if first call
                {  
                    m_pinstance = new PartnerDllInfo(callback); 
                }
                return m_pinstance; 
            }
            static void Release()
            {
                m_instance_count--;
                if((0 == m_instance_count) && m_pinstance)
                {
                    delete m_pinstance;
                    m_pinstance = 0;
                }
                
            }

            static const char* GetStaticDllGuid()
            {
                return DLL_GUID;
            }

            static const char* GetStaticDeviceGuid()
            {
                return DEVICE_GUID;
            }

            // Define accessor methods
			const RtpString<>  getVersionString() const { return m_version_string; }
			const RtpString<> getVendorString() const { return m_vendor_string; }
			unsigned int getVersionMajor()  const { return m_versionMajor; }
            unsigned int getVersionMinor()  const { return m_versionMinor; }
			const RtpString<char>  getDllGuid() const { return m_dllGuid; }

            ~PartnerDllInfo() {}

        protected:

            // Constructor
            // callback is for the RTP_CALLBACK_DEVICE_CONNECT/RTP_CALLBACK_DEVICE_DISCONNECT callbacks
            // it should be used for notification when a removable token storage device
            // is connected or disconnected
            PartnerDllInfo(RSA::IRsaCallback *callback)
            {   
                // set callback
                callback ? m_callback = callback : m_callback = 0;

                // device information
                m_versionMajor = 1;
				m_versionMinor = 0;
				m_dllGuid = RtpString<char>(DLL_GUID,39);
                m_vendor_string = RtpString<>((CK_UTF8CHAR*)"RSA Sample Token Plugin",24);
				m_version_string = RtpString<>((CK_UTF8CHAR*)"1.0",4);
                RSA::SecurID::OtpAlgorithmType otpAlgorithm;
                otpAlgorithm.RsaTotp128 = true;             // only support 128-bit, time-based OTP algorithm
           
                // Create your new device info object
                m_deviceInfo = new PartnerDeviceInfo(
                    otpAlgorithm,                           // otp algorithm
                    RtpString<>((CK_UTF8CHAR*)"RSA Sample Token Device",24),  // device string
                    m_version_string,                       // version
                    RtpString<char>(DEVICE_GUID,39),        // device guid
                    true,                                   // nextCode mode available
                    true,                                   // activation status
                    m_versionMajor,                         // version - major #
                    m_versionMinor,                         // version - minor #
                    100,                                    // max # of tokens
                    MODE_READ_WRITE,                        // open mode supported
                    m_deviceIcon,                           // icon data
                    0,                                      // icon type
                    RtpString<char>(DEVICE_CLASS_GUID,39),  // class guid
                    RtpString<>(DEVICE_SERIAL,12),          // serial #
                    false,                                  // secure time available
                    false,                                  // ability to set a password
                    true,                                   // token seed stored on device
                    false,                                  // tokencodes generated on device
                    (DeviceInfo::TOKEN_TYPE_30SEC |         // token types supported
                        DeviceInfo::TOKEN_TYPE_60SEC |
                        DeviceInfo::TOKEN_TYPE_6DIGITCODE |
                        DeviceInfo::TOKEN_TYPE_8DIGITCODE),
                    0x0,                                    // direct inputs supported
                    (DeviceInfo::PROVISION_SDTID_FILE |     // supported provisioning methods
                        DeviceInfo::PROVISION_CTKIP)
                    );

                // add the device to a vector
                // for this example, there is only one device
                // some plugins may have multiple devices, in which case they should all have unique device GUIDs
                m_vDeviceInfo.push_back(m_deviceInfo);

                // initialize iterator
                m_iDeviceInfo = m_vDeviceInfo.begin(); 
            }

        public:
            
            /* Implementation of the Iterator interface */

            const DeviceInfo* First()
            {
                m_iDeviceInfo = m_vDeviceInfo.begin(); 
                return CurrentItem();
            }
            const DeviceInfo* Next()
            {  
                m_iDeviceInfo++;  
                return CurrentItem();
            }
            bool IsDone() const 
            { 
                return (m_iDeviceInfo == m_vDeviceInfo.end()); 
            }
            const DeviceInfo* CurrentItem()
            { 
                if ( IsDone() )
                {
                    return 0;
                }
                else
                {
                    return dynamic_cast<RSA::SecurID::DeviceInfo*>(*m_iDeviceInfo);
                }
            } 
        
        private:
            std::vector<PartnerDeviceInfo*>::iterator m_iDeviceInfo;
            std::vector<PartnerDeviceInfo*> m_vDeviceInfo;
            RSA::IRsaCallback *m_callback;
            static PartnerDllInfo* m_pinstance;
            static unsigned int m_instance_count;
			RtpString<char> m_dllGuid;
			RtpString<> m_vendor_string;
			RtpString<> m_version_string;
			int m_versionMajor;
			int m_versionMinor;
            RtpString<CK_BYTE> m_deviceIcon;
            PartnerDeviceInfo* m_deviceInfo;  // the only device

            static const char* DLL_GUID;
            static const char* DEVICE_GUID;
            static const char* DEVICE_CLASS_GUID;
            static const CK_UTF8CHAR* DEVICE_SERIAL;
        };


        /*****************************************************************************************
            PartnerTokenProvider is the class that implements interface to the tokens
        ******************************************************************************************/

        class PartnerTokenProvider : public IRsaTokenProvider
        {
        
        protected:

            // Constructor
            // The callback passed in is for the RTP_CALLBACK_TOKEN_REFRESH callback
            // it should be used for notification that a change occured effecting the
            // tokens happens in another instance (possibly another process)
            PartnerTokenProvider( RSA::IRsaCallback *callback, ITimeProviderLoader* timeProviderLoader)
            {
                // set callback
                callback ? m_callback = callback : m_callback = 0;

                // initialize the Time Provider loader
                timeProviderLoader ? m_timeProviderLoader = timeProviderLoader : m_timeProviderLoader = 0;

                // initialize iterator
                m_iTokenData = m_vTokenData.begin(); 
            }

            // Destructor
            virtual ~PartnerTokenProvider()
            {
                for (unsigned int i=0; i<m_vTokenData.size(); i++)
                {
                    delete m_vTokenData[i];
                }
            }
        
        public:

            // PartnerTokenProvider implements the Singleton design pattern
            // but it should additionally use mutexes to be thread safe
            static PartnerTokenProvider* Instance(RSA::IRsaCallback *callback, RSA::SecurID::ITimeProviderLoader* timeProviderLoader)
            {
                m_instance_count ++;
                if (m_pinstance == 0)  // check if first call
                {  
                    m_pinstance = new PartnerTokenProvider(callback, timeProviderLoader); 
                }
                return m_pinstance; 
            }

            static void Release()
            {
                m_instance_count--;
                if((0 == m_instance_count) && m_pinstance)
                {
                    delete m_pinstance;
                    m_pinstance = 0;
                }
            }

            /* Implement IRsaTokenProvider interface */


            RSA_RTP_ERR GetTokenCount(size_t & count) const 
            {
                count = m_vTokenData.size(); 
                return RSA_RTP_SUCCESS; 
            }
            
            void GetLastError(ErrorInfo &info)
            {
                /* Getting error information is not currently supported in this sample plugin,
                   it should be supported in all completed plugins
                */
            }

            RSA_RTP_ERR OpenProtectedSession()
            {
                /* This function is called before doing a "protected" opeation
                   such as getting a code, importing, deleting, or setting a token label.
                   Prompting for a password or your other form of authentication should be done 
                   when this is called for the first time.
                */
                return RSA_RTP_SUCCESS; 
            }

            void CloseProtectedSession()
            {
                /* This function is called after completing a "protected" opeation */
            }

            RSA_RTP_ERR SetDevicePassword()
            {
                /* This function is not supported in this sample plugin.
                   Some plugins support this function to allow users to modify
                   the device protection, others do not.
                */
                return RSA_RTP_OPERATION_NOT_SUPPORTED; 
            }
            
            RSA_RTP_ERR GetRsaPublicKey(RtpString<CK_BYTE> &key)
            {
                /* This function is not typically supported in most plugins
                   If method is not implemented then return this constant value
                */
                return RSA_RTP_OPERATION_NOT_SUPPORTED;
            }

            RSA_RTP_ERR SetTokenLabel(const RtpString<>&tokenSerial, const RtpString<>&label )
            {
                /* Setting token label is not currently supported in this sample plugin,
                   it should be supported in all completed plugins, and the label will have to be
                   persisted in order to remain the same the next time the token is used
                */
                return RSA_RTP_FAILURE; 
            }

            // The following functions are implemented in the CPP file
            RSA_RTP_ERR GetCode(const RtpString<> &serial,const RtpString<> &pin, int &timeRemaining, RtpString<> &code, bool next = false);
            RSA_RTP_ERR ImportToken(const RsaTokenImportData &importData);
            RSA_RTP_ERR DeleteToken(const RtpString<> &serial);
            

            /* Implement the Iterator interface */

            const RsaTokenData* First()
            {
                m_iTokenData = m_vTokenData.begin(); 
                return CurrentItem();

            }
            const RsaTokenData* Next()
            {  
                m_iTokenData++;  
                return CurrentItem();
            }
            bool IsDone() const 
            { 
                return (m_iTokenData == m_vTokenData.end()); 
            }
            const RsaTokenData* CurrentItem()
            { 
                if( IsDone() )
                {
                    return 0;
                }
                else 
                {
                    return *m_iTokenData;
                } 
            }
        
        private:

            // Methods
            RSA_TIME_PROVIDER_ERROR getCurrentTime(unsigned int& currentTime);
            unsigned int GetSecsRemaining(const unsigned int& currentTime, const unsigned int& interval);
            RSA_TIME_PROVIDER_ERROR isExpired(const unsigned int& currentTime, CK_DATE startDate, CK_DATE endDate, bool& isExpired);
            
            // Members
            std::vector<RsaTokenData*>::iterator m_iTokenData;
            std::vector<RsaTokenData*> m_vTokenData;
            static PartnerTokenProvider* m_pinstance;
            static unsigned int m_instance_count;
            RSA::IRsaCallback *m_callback;
            ITimeProviderLoader* m_timeProviderLoader;
        };

    }
}