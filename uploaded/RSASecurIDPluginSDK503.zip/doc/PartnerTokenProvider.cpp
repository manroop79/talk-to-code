// PartnerShim.cpp : Defines the entry point for the DLL application.

/*
 * COPYRIGHT (C) 2009-2015 EMC Corporation
 * ALL RIGHTS RESERVED.
 *  
 * This software contains the intellectual property of EMC Corporation 
 * or is licensed to EMC Corporation from third parties. Use of this software 
 * and the intellectual property contained therein is expressly limited 
 * to the terms and conditions of the License Agreement under which it is 
 * provided by or on behalf of EMC.  
 *   
 */

#include "PartnerTokenProvider.h"
#include <time.h>
#include "logger.h"
#include "logmessages.h"

using namespace RSA::SecurID;


// Define static constants of PartnerDllInfo class
// The DLL GUID, the device GUID, and the device class GUID MUST all be DCE variant UUIDs
const char* PartnerDllInfo::DLL_GUID = "{afc19322-7536-494c-a2e7-d8565525621c}";
const char* PartnerDllInfo::DEVICE_GUID = "{d72b7872-ab21-4604-9123-6440dd4f0f0a}";
const char* PartnerDllInfo::DEVICE_CLASS_GUID = "{41e2d3cb-fbb5-4b82-8028-f1899edeec12}";
const CK_UTF8CHAR* PartnerDllInfo::DEVICE_SERIAL = (CK_UTF8CHAR*)"123456789123";


// Init instance reference counters and ptrs
PartnerTokenProvider* PartnerTokenProvider::m_pinstance = 0;
unsigned int PartnerTokenProvider::m_instance_count = 0;
PartnerDllInfo* PartnerDllInfo::m_pinstance = 0;
unsigned int PartnerDllInfo::m_instance_count = 0;



/* We first need to implement the alloc and dealloc methods for RtpString 

    This code may be kept as-is in production plugins
*/

typedef void* (*ALLOCATOR)(size_t);
typedef void  (*DEALLOCATOR)(void*);

static ALLOCATOR g_alloc = 0;
static DEALLOCATOR g_dealloc = 0;

void RSA_RTP_SetAllocator(void *a, void *d) // from RSATokenProvider interface
{
    g_alloc = (ALLOCATOR)a;
	g_dealloc = (DEALLOCATOR)d;
}

void* RtpStringAllocator::alloc(size_t size)
{
    if(g_alloc)
		return g_alloc(size);
	else
		return 0; 
}

void RtpStringAllocator::dealloc(void *p)
{
    if(p && g_dealloc)
		g_dealloc(p);
}


/* The GetVersion() function should also be used exactly as below */
unsigned int RSA_RTP_GetVersion()
{
    return RSA::SecurID::RTP_VERSION;
}


/* Next we'll specify the IRsaTokenProvider implementation */

RSA_PARTNER_RTP_API DllInfo* RSA_RTP_GetDllInfo(RSA::IRsaCallback *callback)
{
    // return an instance of the plugin
    return dynamic_cast<DllInfo*>(PartnerDllInfo::Instance(callback));
}


IRsaTokenProvider* RSA_RTP_CreateProviderInstance(const char* guid, RSA::IRsaCallback *callback, ITimeProviderLoader* timeProviderLoader)
{
    // check to make sure the device is your device
    if (strcmp(guid, PartnerDllInfo::GetStaticDeviceGuid()) == 0)
    {
        // The dynamic cast is just to make sure that it is derived from the interface.
        return dynamic_cast<IRsaTokenProvider*>(PartnerTokenProvider::Instance(callback, timeProviderLoader)); 
    }
    else
    {
        return 0;
    }
}


void RSA_RTP_ReleaseProviderInstance(IRsaTokenProvider* instance)
{
    // check to make sure the device is your device by doing dynamic cast
    PartnerTokenProvider* partnerInstance = dynamic_cast<PartnerTokenProvider*>(instance);
    if (partnerInstance)
    {
        PartnerTokenProvider::Release();
    }
}


void RSA_RTP_ReleaseDllInfoInstance(RSA::SecurID::DllInfo* instance)
{
    // make sure the plugin is your plugin
    if (instance && strcmp(instance->getDllGuid().get(), PartnerDllInfo::GetStaticDllGuid()) == 0)
    {
        PartnerDllInfo::Release();
    }
}



/*
*   Currently in this sample plugin, this function just deletes a token from the iterator.
*   In production plugins, the token must also be deleted from persistent storage
*
*   In the case of a failure, the error status should be saved so that it can be returned when GetLastError is called
*/
RSA_RTP_ERR PartnerTokenProvider::DeleteToken(const RtpString<> &serial)
{
    std::vector<RsaTokenData*>::iterator theIterator;
	theIterator = m_vTokenData.begin();

	while (theIterator != m_vTokenData.end()) 
    {
        // check to see that we have a valid token
		if (*theIterator != 0 && strcmp((char*)((*theIterator)->getSerialNumber().get()),(char*)serial.get()) == 0) 
        {
            // at this point, the token should be removed from persistant storage

            // remove from vector
			delete (*theIterator);
			m_vTokenData.erase(theIterator);

			return RSA_RTP_SUCCESS;
		}
		theIterator++;
	}

	return RSA_RTP_FAILURE;
}


/*
*   Currently in this sample plugin, this function just adds a token to the iterator.
*   In production plugins, the token must also be written to persistent storage
*
*   In the case of a failure, the error status should be saved so that it can be returned when GetLastError is called
*/
RSA_RTP_ERR PartnerTokenProvider::ImportToken(const RsaTokenImportData &importData)
{
    std::vector<RsaTokenData*>::iterator theIterator;
	theIterator = m_vTokenData.begin();

	// first check to see if serial has been imported already
	while (theIterator != m_vTokenData.end()) 
    {
        if (*theIterator == 0 || strcmp((char*)((*theIterator)->getSerialNumber().get()),(char*)importData.getSerialNumber().get()) == 0) 
        {	
			// importing the same serial number twice is not supported
			return RSA_RTP_DUPLICATE_SERIAL_NUMBER;
		}
		theIterator++;
	}
	
    // import the token to persistant storage
    // PartnerTokenInfo is used by this sample to store attribute information
    // NOTE: the seed information (importData.getSeed()) MUST also be stored (although it isn't in this example)
    // For production plugins, the token data will have to be persisted onto non-volitile storage

    // add to vector
	RsaTokenData *temp = new PartnerTokenInfo(importData);
	m_vTokenData.push_back(temp);
	
    return RSA_RTP_SUCCESS;
}


// Helper function to calculate the number of seconds until the next tokencode
unsigned int PartnerTokenProvider::GetSecsRemaining(const unsigned int& currentTime, const unsigned int& interval)
{
    unsigned int timeRemaining = interval - (currentTime % interval);
    return timeRemaining;
}

/* Helper function used to retrieve the system time. If the tokencode is being calculated 
   based on a device time, that time should be used instead. */ 
RSA_TIME_PROVIDER_ERROR PartnerTokenProvider::getCurrentTime(unsigned int& currentTime)
{
    RSA_TIME_PROVIDER_ERROR err = RSA_TIME_PROVIDER_FAILURE;
    currentTime = 0;

    RsaLogger::Logger::logDebug( RsaLogger::LIBRARY_LOGGER, "In PartnerTokenProvider::getCurrentTime() -- BEGIN");

    if (m_timeProviderLoader != NULL)
    {   
        ITimeProvider* timeProvider = m_timeProviderLoader->getTimeProvider();
        if (timeProvider != NULL)
        {
            RsaLogger::Logger::logDebug( RsaLogger::LIBRARY_LOGGER, "In RTPTokenProvider::getCurrentTime() -- Provider found -- USE");
            err = timeProvider->getTime(currentTime);
        }
    }

    if (err != RSA_TIME_PROVIDER_FAILURE && currentTime != 0) 
    {
        err = RSA_TIME_PROVIDER_SUCCESS;
    }

    return err;
}

/*
*   Currently in this sample plugin, this function just returns a random number for a tokencode.
*   In production plugins, the RSA OTP generation library must be used.
*
*   Additionally, in this sample plugin, the "next" flag is ignored.
*   For production-ready plugins, it should retrieve the next code by
*   adding the token interval to the current time and passing it to the 
*   tokencode generation function.
*   If the plugin is unable to generate the next code immediately, it should block until the next code
*   can be generated, and then return it. In this case, the function canGetNextCode() for the device should
*   return false.
*
*   The PIN field can be ignored as the PIN is no longer passed into this function.
*
*   In the case of a failure, the error status should be saved so that it can be returned when GetLastError is called
*/
RSA_RTP_ERR PartnerTokenProvider::GetCode(const RtpString<> &serial,const RtpString<> &pin, int &timeRemaining, RtpString<> &code, bool next)
{
    std::vector<RsaTokenData*>::iterator theIterator;
	theIterator = m_vTokenData.begin();

	while (theIterator != m_vTokenData.end()) 
    {
        // check to see if the token was found
		if (*theIterator != 0 && strcmp((char*)((*theIterator)->getSerialNumber().get()),(char*)serial.get()) == 0) 
        {
            // retrieve the current system time
            RSA_TIME_PROVIDER_ERROR err = RSA_TIME_PROVIDER_FAILURE;
            unsigned int currentTime = 0;
            err = getCurrentTime(currentTime);
            if (err == RSA_TIME_PROVIDER_FAILURE || currentTime == 0)
            {
                return RSA_RTP_FAILURE;
            }

            // next we check if the token has expired
            bool expirationStatus = true;
            err = RSA_TIME_PROVIDER_FAILURE;
            err = isExpired(currentTime, (*theIterator)->getBirthDate(), (*theIterator)->getDeathDate(), expirationStatus);
			if (err == RSA_TIME_PROVIDER_FAILURE || expirationStatus == true)
            {
				return RSA_RTP_FAILURE;
			}
			
            // clear the tokencode buffer
            code.reset();

            // set a random starting point for our new tokencode
			srand( (unsigned int)time(NULL) );

            // create tmp buffer
            unsigned int tempSize = ((*theIterator)->getOtpDigits()+1);
			char *temp = new char[tempSize];

            // copy random numbers into tmp buffer
			for (unsigned int i=0; i<(*theIterator)->getOtpDigits(); i++) 
            {
				temp[i] = (rand() % 10) + '0';
			}

			temp[tempSize-1] = '\0';

            // set the new tokencode and delete the tmp buffer
            code = RtpString<>((CK_UTF8CHAR*)temp,tempSize);
            delete temp;
            
            timeRemaining = GetSecsRemaining(currentTime, (*theIterator)->getOtpInterval());
            
			return RSA_RTP_SUCCESS;
		}

		theIterator++;
	}

	return RSA_RTP_FAILURE;
}

// Note: since the parameters come from a CK_DATE struct, they are not assumed to be NULL-terminated
time_t generateTime(time_t initialTime,char* year,char* month, char* day)
{
	char temp[5];
	struct tm* timeStruct;

	timeStruct = gmtime(&initialTime);
	if (!timeStruct) {
	   return -1;
    }
	
	memset(temp,0,sizeof(temp));
	strncat(temp,year,4);
	timeStruct->tm_year = atoi(temp) - 1900;
	memset(temp,0,sizeof(temp));
	strncat(temp,month,2);
	timeStruct->tm_mon = atoi(temp) - 1;
	memset(temp,0,sizeof(temp));
	strncat(temp,day,2);
	timeStruct->tm_mday = atoi(temp);

    timeStruct->tm_hour = 0;
    timeStruct->tm_min = 0;
    timeStruct->tm_sec = 0;

	return mktime(timeStruct);
}


/* This helper function returns an expiration status of true if the token is expired or hasn't been born yet;
   returns an expiration status of false otherwise. */ 
// Tokens expire at midnight UTC time on the death date
// Note: Fields inside CK_DATE struct are not NULL-terminated
RSA_TIME_PROVIDER_ERROR PartnerTokenProvider::isExpired(const unsigned int& currentTime, CK_DATE startDate, CK_DATE endDate, bool& isExpired)
{
	time_t initialTime, theStart, theEnd;

    initialTime = currentTime;
	theStart = generateTime(initialTime,(char*)startDate.year,(char*)startDate.month,(char*)startDate.day);
	theEnd = generateTime(initialTime,(char*)endDate.year,(char*)endDate.month,(char*)endDate.day);

    if (theStart == -1 || theEnd == -1)
    {
        return RSA_TIME_PROVIDER_FAILURE;
    }

	if (difftime(initialTime,theStart) < 0.0 || difftime(theEnd,initialTime) < 0.0)
    {  
        // expired or not born yet
		isExpired = true;
    }
	else
    {   // not expired
		isExpired = false;
    }

    return RSA_TIME_PROVIDER_SUCCESS;
}
