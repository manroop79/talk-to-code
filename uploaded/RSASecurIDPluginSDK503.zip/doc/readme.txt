Copyright � 2009-2015 EMC Corporation 
All Rights Reserved

This software contains the intellectual property of EMC Corporation or is licensed to 
EMC Corporation from third parties. Use of this software and the intellectual property 
contained therein is expressly limited to the terms and conditions of the License
Agreement under which it is provided by or on behalf of EMC.



This zip file consists of the following components:

     doc - includes RSATokenProvider.chm, stautoexamplereg.reg, and a sample
           plugin, PartnerTokenProvider. RSATokenProvider.chm details the 
           token provider plugin interface.  stautoexamplereg.reg is an example 
           registry file for registering a device plugin.  PartnerTokenProvider
           is a *sample* plugin.

     include - includes all of the needed header files for development

     mergeModule - includes the merge module, Stauto32Plugin.msm, for redist of stauto32.dll.


Brief header file descriptions:

irsacallback.h        - Callback event interface
itimeproviderloader.h - Time provider loader interface for loading a time source
rsatimeprovider.h     - RSA Time Provider Interface for implementing time plug-ins
rsatokenprovider.h    - RSA Token Provider Interface for implementing token plug-ins
rtpstring.h           - Simple string class
rtptokendata.h        - Class for handling token attribute metadata
stautoreg.h           - Class for handling the import/removal of registry settings


The DLLs needed for development can be located in "Program Files/RSA/RSA SecurID Token Common" 
after RSASecurIDSetup.exe has completed installation.  

Note that RegisterRtpDll has the following entry points:

	bool Import(const char* path, bool systemScope);    // Imports a token plug-in into the registry
	bool Remove(const char* path, bool systemScope);    // Removes a token plug-in from the registry
	
	The 'Import' and 'Remove' functions take two parameters, the first being a path to a token plug-in and 
	second being the registry scope.  The second parameter must be set to true as registering a token-plugin 
	in the user-scope is no longer supported.
	
	bool RegisterTimePlugin(const char* const path);    // Imports a time plug-in into the registry
	bool UnregisterTimePlugin(const char* const path);  // Removes a time plug-in from the registr