<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <source>Token name cannot be blank.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token name must contain between 1 and 24 characters.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<TS version="2.0" language="en_US">
<context>
    <name>AboutSID</name>
    <message>
        <source>Plug-in Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plug in name: %1, Version number: %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AboutSIDDialog</name>
    <message>
        <source>About RSA SecurID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About RSA Secure ID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installed Plug ins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installed Plug-ins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Application Name Place Holder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Application version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Library version </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copyright 2021 RSA Security LLC or its affiliates.  All Rights Reserved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>© 2021 RSA Security LLC or its affiliates.  All Rights Reserved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time and Zone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plug-in Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version Number</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExpirationNotification</name>
    <message>
        <source>Click here to request a replacement token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token named &quot;%1&quot; will expire in %2 days. Contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multiple tokens will expire in %1 days. Contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token named &quot;%1&quot; has expired.  Contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multiple tokens have expired. Contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportDialog</name>
    <message>
        <source>Import Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Need help importing a token?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Need help importing a token?&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select token import method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select token import method:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import from File - Browse to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Import from File&lt;/b&gt;&lt;/font&gt;&lt;/a&gt; - Browse to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a file saved on your computer (.sdtid extension).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import from Web - Enter an</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Import from Web&lt;/b&gt;&lt;/font&gt;&lt;/a&gt; - Enter an</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>activation code and URL (if required).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Need to view device information?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token Storage Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Token Storage Device&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter token file path or click Browse:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token path field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter token path or click browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import from File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Import from File&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Need help importing from file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Need help importing from file?&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import from Web</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Import from Web&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter URL:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>URL field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Activation Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Activation Code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Activation code field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Activation code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Need help importing from web?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Need help importing from web?&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstallToken</name>
    <message>
        <source>Import from File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import from Web</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token Import Files (*.sdtid)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManageDevice</name>
    <message>
        <source>Device Name: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Device Serial Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Device Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token Serial Number</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManageDeviceDialog</name>
    <message>
        <source>Token Storage Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Need help managing devices?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Need help managing devices?&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Device button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Device Password button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Device Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MenuBar</name>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SecurID Help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionMenu</name>
    <message>
        <source>Import Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Token Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token Information...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token Storage Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Always on Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PINMainWindow</name>
    <message>
        <source>RSA SecurID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA Secure ID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimize button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter PIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter pin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;font size=&quot;3&quot; color=&quot;#24566d&quot;&gt;&lt;b&gt;Enter PIN:&lt;/b&gt;&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasscodeFullWindow</name>
    <message>
        <source>RSA SecurID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA Secure ID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Passcode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimize button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Passcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Re enter pin button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Re-enter PIN</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasscodeMode</name>
    <message>
        <source>No Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token Expired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 seconds remaining</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current code is %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next token code is %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tokencode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Passcode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next Code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to change token name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Application already contains a token named %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasscodeText</name>
    <message>
        <source>Copy Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <comment>Copy shortcut command</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PinText</name>
    <message>
        <source>Paste PIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+V</source>
        <comment>Paste shortcut command</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgressBox</name>
    <message>
        <source>%1 Seconds remaining</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgressMeterClass</name>
    <message>
        <source>RSA SecurID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA Secure ID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importing token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importing Token...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCheckBox</name>
    <message>
        <source>Uncheck</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QMenu</name>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>RSA SecurID Software Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA SecurID Software Token with Automation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA Secure ID Software Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA WebID Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete &quot;%1&quot;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last token deleted. Import new token?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token file &quot;%1&quot; not found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to delete token.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must have a token imported to run the application. Click Close to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token name successfully changed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PIN must contain 4 to 8 digits.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must enter file path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must enter a URL.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must enter an activation code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token import failed. Verify that the information entered is correct or contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>URL must start with http:// or https://.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid URL.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to change password on %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Passwords are not supported for this device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 successfully enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to enable %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must choose a device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected device must be enabled first.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incorrect password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token import failed. Invalid token. Contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token not intended for this device. Token import failed. Contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token import failed. Cannot open file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can store only one token. Importing a new token will overwrite all your existing tokens. Click OK to import the new token.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error communicating with server. Token import failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token import failed. Duplicate token.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Device inaccessible. Cannot retrieve token.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Device intended for this token not found. Token import failed. Connect the device or contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token import failed.  Maximum number of tokens already stored on device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>expired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - RSA SecurID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - RSA Secure ID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token import failed. Expired token.  Contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No token storage device was detected. Verify that the device is attached or contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum Tokens Exceeded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importing token from web...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importing token...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Software token library failed. Contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must close the Token Transfer Utility before running the SecurID application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPushButton</name>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QRadioButton</name>
    <message>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QToolButton</name>
    <message>
        <source>Press</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SelectDevice</name>
    <message>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SelectDeviceDialog</name>
    <message>
        <source>Select Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the device where the token will be stored:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Need help with devices?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Need help with devices?&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Device button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TokenFilePwdDialog</name>
    <message>
        <source>Enter File Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To complete import of %1 file enter a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Enter Password:&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File password field</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TokenInfoDialog</name>
    <message>
        <source>Token Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token Serial Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expiration Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Device Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Device Serial Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Need help with token information?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Need help with token information?&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TokenInformation</name>
    <message>
        <source>dddd&apos;,&apos; MMMM dd&apos;,&apos; yyyy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TokenMessageBox</name>
    <message>
        <source>RSA SecurID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA Secure ID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>expirationNotificationDialog</name>
    <message>
        <source>Token Expiration Notification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tokens about to expire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token about to expire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for replacement token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot;&quot;&gt;Click here to request a replacement token&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>importconfirmationDialog</name>
    <message>
        <source>RSA SecurID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA Secure ID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token import successful</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Token named %1 successfully imported to %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Want to change token name?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Name Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>renameDialog</name>
    <message>
        <source>Change Token Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Need help changing token name?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Need help changing token name?&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Change Name:&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change name field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<TS version="2.0" language="en_US">
<context>
    <name>MainDialog</name>
    <message>
        <source>RSA SecurID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Token:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter User Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter PIN:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Need help logging on?&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter your user name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter your passcode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter PIN.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PIN must contain 4 to 8 alphanumeric characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PIN must contain 4 to 8 digits.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a token from the token selction box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Passcode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hardware Token</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewPIN</name>
    <message>
        <source>Your RSA SecurID PIN must contain between 4 to 8 alphanumeric characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a PIN generation radio button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The PINs entered do not match.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PIN must contain 4 to 8 alphanumeric characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PIN must contain 4 to 8 digits.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NextDialog</name>
    <message>
        <source>Enter the next tokencode displayed on your token.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgressMeterClass</name>
    <message>
        <source>RSA SecurID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA Secure ID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importing token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importing Token...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Unable to load help file. Open the SecurID application and select Options &gt; Help.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to retrieve passcode. Contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Software token library failed. Contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are not authorized to access this URL.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TokenMessageBox</name>
    <message>
        <source>RSA SecurID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA Secure ID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>newPINDialog</name>
    <message>
        <source>Set New RSA SecurID PIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have an RSA SecurID PIN, or your security policy requires a PIN change.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA SecurID PIN Creation Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generate PIN for me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I will create my own PIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter PIN:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm PIN:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your RSA SecurID PIN must contain between 4 to 8 digits.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>nextTokenDialog</name>
    <message>
        <source>Enter Next Tokencode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wait for the code on your token to change and enter it below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Next Tokencode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Need help with next token code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Need help with next tokencode?&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>systemPinDialog</name>
    <message>
        <source>New RSA SecurID PIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your New PIN: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please memorize your PIN and click Ok.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<TS version="2.0" language="en_US">
<context>
    <name>ChangePwd</name>
    <message>
        <source>You must enter the same password to confirm your change.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: By proceeding, all tokens on the selected device will be deleted and the device password will be reset.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangePwdDialog</name>
    <message>
        <source>Change Device Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set a password to protect tokens stored on your hard drive. To remove an existing password, leave the new password and confirm password fields blank.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set a password to protect tokens stored on your hard drive. To remove an existing password, leave the new and confirm password fields blank.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Need help setting device password?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;a href=&quot; &quot;&gt;Need help setting device password?&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forgot your password?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset device button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DevicePwdDialog</name>
    <message>
        <source>Enter Device Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The token database on your hard drive is protected by a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Password:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Incorrect password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Successfully deleted tokens and removed password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Operation failed. Contact your administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password must contain between 0 and %1 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password removal successful.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password change successful.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local Hard Drive (RSA)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TokenMessageBox</name>
    <message>
        <source>RSA SecurID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA Secure ID Token</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
